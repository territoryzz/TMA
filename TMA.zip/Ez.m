%Ez
function [Ez] = Ez(theta, r, z, omega, t, theta0, a, b, kphi1, kphi2)
theta2=Theta2(omega,t,theta0);
theta1=0;
Ez = kphi1*F6(theta, r, z, theta1, a, b) + kphi2*F6(theta, r, z, theta2, a, b);
end