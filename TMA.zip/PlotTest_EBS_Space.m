clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;
theta0 = 30;

%% 设置 A，phi 的计算常数
ka = -mu*sigma*theta0*omega/(4*pi);
kphi2 = sigma/(4*pi*epsilon0);
kphi1 = -sigma/(4*pi*epsilon0);

%% 绘制 z = z_fixed 的情况下，在此平面的分布
% 定义 r 和 theta 的范围
num_theta_points = 100;
num_r_points = 100;
r_values = linspace(0, 0.3, num_r_points);  % 例如，0 到最大 r 值，num_r_points 个点
theta_values = linspace(-pi, pi, num_theta_points);  % 角度从 -pi 到 pi

% 选取 t = 1/3T 时，绘制 z = z_fixed 处
z_fixed = 0.15;
t_fixed = 1/3 * 2*pi/omega;

% 初始化 B 数值数组
B_values = zeros(num_theta_points, num_r_points);

% 循环计算 B 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r = r_values(j);
        theta = theta_values(i);
        
        % 计算 B 的值并存储在 B_values 中
        B_values(i, j) = B(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka);
    end
end

% 初始化 E 数值数组
E_values = zeros(num_theta_points, num_r_points);

% 循环计算 E 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r = r_values(j);
        theta = theta_values(i);
        
        % 计算 E 的值并存储在 E_values 中
        E_values(i, j) = E(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
    end
end

% 初始化 S 数值数组
S_values = zeros(num_theta_points, num_r_points);

% 循环计算 S 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r = r_values(j);
        theta = theta_values(i);
        
        % 计算 S 的值并存储在 S_values 中
        S_values(i, j) = S(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
    end
end

% 转换为笛卡尔坐标
[R, Theta] = meshgrid(r_values, theta_values);
X = R .* cos(Theta);
Y = R .* sin(Theta);

% 设置保存路径
save_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/TestPlot/';

% 绘制 B 二维表面图
figure;
surf(X, Y, B_values, 'EdgeColor', 'none'); % 去除边框线
colormap(jet); % 更鲜艳的颜色映射
alpha(0.7); % 设置透明度
xlabel('x');
ylabel('y');
zlabel('B');
title(['B 关于 x 和 y 的分布 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);
set(gca, 'Color', 'none'); % 设置背景透明
saveas(gcf, fullfile(save_path, 'B_plot.svg'));

% 绘制 E 二维表面图
figure;
surf(X, Y, E_values, 'EdgeColor', 'none'); % 去除边框线
colormap(hot); % 更鲜艳的颜色映射
alpha(0.7); % 设置透明度
xlabel('x');
ylabel('y');
zlabel('E');
title(['E 关于 x 和 y 的分布 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);
set(gca, 'Color', 'none'); % 设置背景透明
saveas(gcf, fullfile(save_path, 'E_plot.svg'));

% 绘制 S 二维表面图
figure;
surf(X, Y, S_values, 'EdgeColor', 'none'); % 去除边框线
colormap(jet); % 更鲜艳的颜色映射
alpha(0.7); % 设置透明度
xlabel('x');
ylabel('y');
zlabel('S');
title(['S 关于 x 和 y 的分布 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);
set(gca, 'Color', 'none'); % 设置背景透明
saveas(gcf, fullfile(save_path, 'S_plot.svg'));
