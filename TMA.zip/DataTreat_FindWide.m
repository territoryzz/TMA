%lobe pattern
clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);

%考虑绘制波瓣图，那么必须考虑在远场情况下，波长条件难以满足，故仅满足器件尺寸条件和瑞丽条件r>2*D^2/lambda
%初步选定 R = 0.25
%取t=1/4T
R = 0.25;
t_fixed =1/4 * 2*pi/omega;

%先要寻找S主峰分布的位置

% 生成一组离散的 theta 和 phi 值
num_theta = 100;
num_phi = 100;
theta_range = linspace(0, 2*pi, num_theta);
phi_range = linspace(0, pi, num_phi);


% 初始化函数值数组
S_values = zeros(num_theta, num_phi);

% 计算函数值
for i = 1:num_theta
    for j = 1:num_phi
        % 计算函数值
        S_values(i, j) = S_sphere(theta_range(i), R, phi_range(j), omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
    end
end




save('S_values.mat', 'S_values');


% 只分析查找程序，节约一次次算 S 的时间
load('S_values.mat');



%% 找到最大值及其位置
[max_value, max_index] = max(S_values(:));
[max_row, max_col] = ind2sub(size(S_values), max_index);
max_theta = theta_range(max_row);
max_phi = phi_range(max_col);

% 将结果写入文件
fileID = fopen('max_value_theta_phi.txt', 'w');
fprintf(fileID, '最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n', max_value, max_theta, rad2deg(max_theta), max_phi, rad2deg(max_phi));
fclose(fileID);

% 显示结果
fprintf('最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n', max_value, max_theta,rad2deg(max_theta), max_phi,rad2deg(max_phi));




%% 找到半功率波束范围
half_max_power = 1/2 *max_value;

% 在 theta 方向找到半功率点
half_power_theta_index = find(S_values(:, max_col) >= half_max_power);
if isempty(half_power_theta_index)
    error('未找到 theta 方向上的半功率点。');
end
hpbw_theta = max(theta_range(half_power_theta_index)) - min(theta_range(half_power_theta_index));

% 在 phi 方向找到半功率点
half_power_phi_index = find(S_values(max_row, :) >= half_max_power);
if isempty(half_power_phi_index)
    error('未找到 phi 方向上的半功率点。');
end
hpbw_phi = max(phi_range(half_power_phi_index)) - min(phi_range(half_power_phi_index));

% 显示结果
fprintf('波束范围为：theta 方向 %f 度 到 %f 度\n', rad2deg(min(theta_range(half_power_theta_index))), rad2deg(max(theta_range(half_power_theta_index))));
fprintf('波束范围为：phi 方向 %f 度 到 %f 度\n', rad2deg(min(phi_range(half_power_phi_index))), rad2deg(max(phi_range(half_power_phi_index))));
fprintf('波束范围为：theta 方向 %f 度，phi 方向 %f 度\n', rad2deg(hpbw_theta), rad2deg(hpbw_phi));





% %% 找到第一个零点的位置
% first_null_theta_index = find(S_values(max_row, :) <= 0, 1, 'first');
% first_null_phi_index = find(S_values(:, max_col) <= 0, 1, 'first');
% 
% % 检查是否找到第一个零点
% if isempty(first_null_theta_index) || isempty(first_null_phi_index)
%     error('未找到第一个零点。');
% end
% 
% % 计算 FNBW
% fnbw_theta = abs(theta_range(first_null_theta_index) - theta_range(max_row));
% fnbw_phi = abs(phi_range(first_null_phi_index) - phi_range(max_col));
% 
% % 显示结果
% fprintf('第一零点波束宽度为：theta 方向 %f 度，phi 方向 %f 度\n', rad2deg(fnbw_theta), rad2deg(fnbw_phi));



%% 绘制图像进行检查
% 绘制关于 theta 的图像
figure;
plot(rad2deg(theta_range), S_values(:, max_col)); % 使用 rad2deg 将弧度转换为度
xlabel('Theta (degrees)');
ylabel('S');
title(['S plot at phi = ', num2str(rad2deg(phi_range(max_col))), '°']);
% 添加半功率的水平线
yline(half_max_power, '--', '半功率');

% 绘制关于 phi 的图像
figure;
plot(rad2deg(phi_range), S_values(max_row, :)); % 使用 rad2deg 将弧度转换为度
xlabel('Phi (degrees)');
ylabel('S');
title(['S plot at theta = ', num2str(rad2deg(theta_range(max_row))), '°']);
% 添加半功率的水平线
yline(half_max_power, '--', '半功率');