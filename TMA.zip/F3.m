function [F3] = F3(theta, r, z, thetaf, a, b)
    % 定义积分函数的句柄，传递场点位置 r 和 z 作为额外参数
    F3_integrand = @(rf, zf) F3f(theta, r, z, thetaf, rf, zf);
    % 执行积分计算
    F3 = integral2(F3_integrand, 0, a, 0, b);
end
