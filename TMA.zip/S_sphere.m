% 球坐标下的函数
function [S_sphere] = S_sphere(thetas, R, phis, omega, t, theta0, a, b, ka, kphi1, kphi2, mu)
    %将柱坐标用球坐标参数表示
    r = R*sin(phis);
    z = R*cos(phis); 
    S_sphere = S(thetas, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2, mu);
end

