%%%test
clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;
theta0 = 30; % 此处为角度值，在theta2函数内完成了转换为弧度制

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);


%% 选取点（0.15, 30°, 0.15）做随时间变换的图像
r_point = 0.15;
theta_point = deg2rad(30); % 将角度转换为弧度
z_point = 0.15;

% 时间向量
t = linspace(0, 3*2*pi/omega, 100); % 假设三个周期的波

% 计算给定点和时间向量的test值   theta_point, r_point,z_point
thetaf = Theta2(omega,t,theta0); % theta2函数内完成了将角度值转换为弧度制的过程

% 计算test随时间变化的值
test_values = zeros(size(t));
for i = 1:length(t)
    test_values(i) = F7(r_point, theta_point, z_point, thetaf(i), a, b);
end

% 绘制test随时间变化的图像
figure;
plot(t, test_values, 'b', 'LineWidth', 2);
xlabel('时间');
ylabel('test');
title('固定点（0.15, 30°, 0.15）随时间变化的test');
grid on;
