%F6f
function [F6f] = F6f(theta, r, z, thetaf, rf, zf)
   F6f = (z-zf)./(r.^2 + rf.^2 - 2*r.*rf.*cos(theta-thetaf)+(z-zf).^2).^3/2;
end
