clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);




%% 选取点（0.15, 30°, 0.15）做随时间变换的图像
r_point = 0.5;
thetaAng=30;
theta_point = deg2rad(thetaAng); % 将角度转换为弧度
z_point = 0.15;

% 时间向量
t = linspace(0, 3*2*pi/omega, 100); % 假设三个周期的波

% 绘制极板运动作为参考
figure; % 创建新的图形窗口
Theta2_values=Theta2(omega,t,theta0);
plot(t, Theta2_values);
xlabel('时间');
ylabel('Theta2');
title('Theta2随时间变化');

thetaf = Theta2(omega,t,theta0); % theta2函数内完成了将角度值转换为弧度制的过程

% 绘制B、E、S大小随时间变化的图
B_values = zeros(size(t));
E_values = zeros(size(t));
S_values = zeros(size(t));

for i = 1:length(t)
    B_values(i) = B(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka);
    E_values(i) = E(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2);
    S_values(i) = S(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2, mu);
end

figure;
plot(t,  B_values);
xlabel('时间');
ylabel(' B');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 B 的大小']);
grid on;

figure;
plot(t,  E_values);
xlabel('时间');
ylabel(' E');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 E 的大小']);
grid on;

figure;
plot(t,  S_values);
xlabel('时间');
ylabel(' S');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 S 的大小']);
grid on;


%% 考虑选取t=1/4T时，绘制z=z_fixed处,r=r_fixed的极坐标下的分布
t_fixed =1/4 * 2*pi/omega;
z_fixed = 0.15;
r_fixed = 0.15;

% 定义 theta 范围
theta = linspace(0, 2*pi, 1000);

% 计算对应位置的场强大小 B
B_values = zeros(size(theta));
for i = 1:numel(theta)
    B_values(i) = B(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka);
end

% 绘制极坐标图
figure;
polarplot(theta(:), B_values(:));
title(['极坐标下B大小分布图 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);

% 计算对应位置的场强大小 E
E_values = zeros(size(theta));
for i = 1:numel(theta)
    E_values(i) = E(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
end

% 绘制极坐标图
figure;
polarplot(theta(:), E_values(:));
% 添加标题，包含 t_fixed 和 z_fixed 的值
title(['极坐标下E大小分布图 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);


% 计算对应位置的场强大小 S
S_values = zeros(size(theta));
for i = 1:numel(theta)
    S_values(i) = S(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
end

% 绘制极坐标图
figure;
polarplot(theta(:), S_values(:));
% 添加标题，包含 t_fixed 和 z_fixed 的值
title(['极坐标下S大小分布图 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);



%% 再考虑绘制z=z_fixed情况下，在此平面的分布
% 定义 r 和 theta 的范围
num_theta_points = 100;
num_r_points = 100;
r_values = linspace(0, 0.5, num_r_points);  % 例如，0 到最大 r 值，num_r_points 个点
theta_values = linspace(-pi, pi, num_theta_points);  % 角度从 -pi 到 pi

%选取t=1/3T时，绘制z=z_fixed处
z_fixed = 0.15;
t_fixed =1/3 * 2*pi/omega;

% 初始化 B 数值数组
B_values = zeros(num_theta_points, num_r_points);

% 循环计算 B 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r = r_values(j);
        theta = theta_values(i);
        
        % 计算 B 的值并存储在 B_values 中
        B_values(i, j) = B(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka);
    end
end

% 初始化 E 数值数组
E_values = zeros(num_theta_points, num_r_points);

% 循环计算 E 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r = r_values(j);
        theta = theta_values(i);
        
        % 计算 E 的值并存储在 E_values 中
        E_values(i, j) = E(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
    end
end

% 初始化 S 数值数组
S_values = zeros(num_theta_points, num_r_points);

% 循环计算 S 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r = r_values(j);
        theta = theta_values(i);
        
        % 计算 E 的值并存储在 E_values 中
        S_values(i, j) = S(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
    end
end


% 转换为笛卡尔坐标
[R, Theta] = meshgrid(r_values, theta_values);
X = R .* cos(Theta);
Y = R .* sin(Theta);

% 绘制 B 三维表面图
figure;
surf(X, Y, B_values);
xlabel('x');
ylabel('y');
zlabel('B');
title(['B 关于 x 和 y 的分布 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);

% 绘制 E 三维表面图
figure;
surf(X, Y, E_values);
xlabel('x');
ylabel('y');
zlabel('E');
title(['E 关于 x 和 y 的分布 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);


% 绘制 S 三维表面图
figure;
surf(X, Y, S_values);
xlabel('x');
ylabel('y');
zlabel('S');
title(['S 关于 x 和 y 的分布 (z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);