clear;
close all;
clc;

delete(gcp('nocreate'));

% 启动新的并行池，设置最大工作数为 CPU 线程数
parpool('local');

pool = gcp('nocreate'); % 获取当前池
if ~isempty(pool)
    disp(['Number of workers: ', num2str(pool.NumWorkers)]);
else
    disp('No parallel pool is currently running.');
end


%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30];
beta_values = [2, 3, 4, 5, 6, 7, 8, 9, 10 , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 40 ,50];
t_factor_values = [1/12, 1/6, 1/4, 1/3, 5/12, 1/2];
theta0_values = [3, 30, 60, 90];

%% 并行计算和保存数据
parfor beta_idx = 1:length(beta_values)
    beta = beta_values(beta_idx);
    R = beta * a;
    
    for omega_idx = 1:length(omega_values)
        omega = omega_values(omega_idx);
        
        for theta0_idx = 1:length(theta0_values)
            theta0 = theta0_values(theta0_idx);

            for t_factor_idx = 1:length(t_factor_values)
                t_factor = t_factor_values(t_factor_idx);
                t_fixed = t_factor * 2*pi/omega;

                ka = -mu * sigma * theta0 * omega / (4*pi);
                kphi2 = sigma / (4*pi*epsilon0);
                kphi1 = -sigma / (4*pi*epsilon0);

                %% 波束范围
                % 构建要读取的 S_values 文件名
                S_file_name = sprintf('S_values_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.mat', omega, theta0, beta, t_factor);

                % 指定 S_values 文件夹路径
                S_folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S_R';

                % 构建完整的文件路径
                S_file_path = fullfile(S_folder_path, S_file_name);

                % 加载 S_values 数组
                loaded_data = load(S_file_path);
                S_values = loaded_data.S_values_clean;
                [max_value, ~] = max(S_values(:));

                % 获取 S 数组的尺寸
                [num_theta, num_phi] = size(S_values);

                % 使用 integral2 函数计算归一化后的积分
                integrand_normalized = @(phi, theta) arrayfun(@(phi, theta) S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu) / max_value, phi, theta) .* sin(phi);
                S_averageIntegral = integral2(integrand_normalized, 0, pi, -pi, pi);

                OmegaA = S_averageIntegral;

                %% 定向性D 
                D = 4*pi/OmegaA;

                %% 有效口径
                A_m = D * (2*pi*c/omega)^2 / (4*pi);

                %% 波束效率计算
                theta_range = linspace(-pi, pi, num_theta);
                phi_range = linspace(0, pi, num_phi);

                % 找到最大值及其位置
                [max_value, max_index] = max(S_values(:));
                [max_row, max_col] = ind2sub(size(S_values), max_index);

                % 查找 theta 方向的主瓣范围
                theta_values = S_values(:, max_col);
                theta_local_minima = islocalmin(theta_values);

                % 初始化 main_lobe_theta_index
                main_lobe_theta_index = zeros(2, 1);

                % 找到最大值附近的极小值（下降到极小值然后再上升）
                theta_min_before_max = find(theta_local_minima & (1:num_theta)' < max_row, 1, 'last');
                theta_min_after_max = find(theta_local_minima & (1:num_theta)' > max_row, 1, 'first');

                if isempty(theta_min_before_max) || isempty(theta_min_after_max)
                    theta_main_max = pi;
                    theta_main_min = -pi;
                else
                    main_lobe_theta_index(1) = theta_min_before_max;
                    main_lobe_theta_index(2) = theta_min_after_max;

                    theta_main_min = theta_range(main_lobe_theta_index(1));
                    theta_main_max = theta_range(main_lobe_theta_index(2)); 
                end
                mbw_theta = theta_main_max - theta_main_min;

                % 查找 phi 方向的主瓣范围
                phi_values = S_values(max_row, :);
                phi_local_minima = islocalmin(phi_values);

                % 初始化 main_lobe_phi_index
                main_lobe_phi_index = zeros(2, 1);

                % 找到最大值附近的极小值（下降到极小值然后再上升）
                phi_min_before_max = find(phi_local_minima & (1:num_phi) < max_col, 1, 'last');
                phi_min_after_max = find(phi_local_minima & (1:num_phi) > max_col, 1, 'first');

                if isempty(phi_min_before_max) || isempty(phi_min_after_max)
                    phi_main_min = 0;
                    phi_main_max = pi;
                else
                    main_lobe_phi_index(1) = phi_min_before_max;
                    main_lobe_phi_index(2) = phi_min_after_max;

                    phi_main_min = phi_range(main_lobe_phi_index(1));
                    phi_main_max = phi_range(main_lobe_phi_index(2));
                end
                mbw_phi = phi_main_max - phi_main_min;

                % 计算 delta_phi 和 delta_theta
                delta_phi = (phi_main_max - phi_main_min) / (num_phi - 1);
                delta_theta = (theta_main_max - theta_main_min) / (num_theta - 1);

                % 生成 phi 和 theta 的网格
                [phi_grid, theta_grid] = meshgrid(linspace(phi_main_min, phi_main_max, num_phi), linspace(theta_main_min, theta_main_max, num_theta));

                % 计算归一化后的 S_sphere_values
                S_sphere_values = arrayfun(@(phi, theta) S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu) / max_value, theta_grid, phi_grid);

                % 使用 integral2 函数计算主瓣的积分
                integrand_main = @(phi, theta) arrayfun(@(phi, theta) S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu) / max_value, phi, theta) .* sin(phi);
                S_averageIntegral_Main = integral2(integrand_main, phi_main_min, phi_main_max, theta_main_min, theta_main_max);

                OmegaM = S_averageIntegral_Main;
                epsilon_M = OmegaM / OmegaA;

                %% 保存数据并在origin中画图

                % 构建文件名
                file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_Beam_Parameter/data_r=%.2f_theta0=%d_Omega=%d_t=%.2fT.csv', R, theta0,omega,t_factor);

                % 检查文件夹是否存在，如果不存在则创建
                folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_Beam_Parameter/';
                if ~exist(folder_path, 'dir')
                    mkdir(folder_path);
                end  

                % 构建要保存的数据矩阵
                data = [OmegaA, D, A_m, OmegaM, epsilon_M];

                % 保存数据到 CSV 文件
                writematrix(data, file_name);

            end
        end
    end
end

disp('数据保存完成！');


