function [hpbw_theta, hpbw_phi] = half_power_beamwidth(S_sphere, ~, theta_range, phi_range, half_max_power)
    % 在 theta 方向寻找半功率波束宽度
    half_power_theta_values = [];
    for i = 1:length(theta_range)
        s_theta = S_sphere(theta_range(i), phi_range, 'theta');
        if any(s_theta >= half_max_power)
            half_power_theta_values = [half_power_theta_values, theta_range(i)];
        end
    end
    if isempty(half_power_theta_values)
        error('未找到 theta 方向上的半功率点。');
    end
    hpbw_theta = max(half_power_theta_values) - min(half_power_theta_values);

    % 在 phi 方向寻找半功率波束宽度
    half_power_phi_values = [];
    for j = 1:length(phi_range)
        s_phi = S_sphere(theta_range, phi_range(j), 'phi');
        if any(s_phi >= half_max_power)
            half_power_phi_values = [half_power_phi_values, phi_range(j)];
        end
    end
    if isempty(half_power_phi_values)
        error('未找到 phi 方向上的半功率点。');
    end
    hpbw_phi = max(half_power_phi_values) - min(half_power_phi_values);
end