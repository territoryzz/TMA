clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30];
theta0_values = [3, 30, 60, 90];
beta_values = [2, 3, 4, 5, 6, 7, 8, 9, 10 , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 40 ,50];
t_factor_values = [1/12, 1/6, 1/4, 1/3, 5/12, 1/2 ];

% 指定结果文件夹路径
result_folder = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_dB';

%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values
        % 设置A，phi的计算常数
        ka = -mu * sigma * theta0 * omega / (4*pi);
        kphi2 = sigma / (4*pi*epsilon0);
        kphi1 = -sigma / (4*pi*epsilon0);

        % 确定 thetafAng 的取值
        thetafAng_values = [theta0, -theta0, 3*theta0];
        for beta = beta_values
            R = beta * a;

            for t_factor = t_factor_values
                t_fixed = t_factor * 2*pi/omega;

                    % 生成一组离散的 theta 和 phi 值
                    num_theta = 360;
                    num_phi = 180;
                    theta_range = linspace(0, 2*pi, num_theta);
                    phi_range = linspace(0, pi, num_phi);





%                 % 构建要读取的文件名
%                 file_name = sprintf('max_value_theta_phi_omega=%d_theta0=%d_beta=%d_t=%.3fT.txt', omega, theta0, beta, t_factor);
% 
%                 % 指定文件路径
%                 folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S/';
% 
%                 % 构建完整的文件路径
%                 file_path = fullfile(folder_path, file_name);
% 
%                % 打开文件以读取
%                fileID = fopen(file_path, 'r');
%                if fileID == -1
%                 error('无法打开文件：%s\n', file_path);
%                end

%             % 读取文件中的数据
%             data = fscanf(fileID, 'omega=%d, theta0=%d, beta=%d, t=%*fT:\n最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n');
%             fclose(fileID);
% 
%             max_value = data(4);
%             max_theta = data(5);
%             max_theta_deg = data(6);
%             max_phi = data(7);
%             max_phi_deg = data(8);

             % 构建要读取的 S_values 文件名
             S_file_name = sprintf('S_values_omega=%d_theta0=%d_beta=%d_tfactor=%.3f.mat', omega, theta0, beta, t_factor);

             % 指定 S_values 文件夹路径
            S_folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S_R';

            % 构建完整的文件路径
            S_file_path = fullfile(S_folder_path, S_file_name);

                % 加载 S_values 数组
                loaded_data = load(S_file_path);
                S_values = loaded_data.S_values_clean;

                % 获取 S 数组的尺寸
                [num_theta, num_phi] = size(S_values);
                
                % 创建一个掩蔽矩阵，将不期望的最大值位置设为 -Inf
                S_values_masked = S_values;
                S_values_masked(:, [1, end]) = -Inf; % Mask phi = 0 and phi = pi
                S_values_masked([1, end], :) = -Inf; % Mask theta = 0 and theta = 2*pi

                [max_value, max_index] = max(S_values_masked(:));
                [max_row, max_col] = ind2sub(size(S_values_masked), max_index);
                max_theta = theta_range(max_row);
                max_phi = phi_range(max_col);


                %% 保存分贝图
                % 构建文件名，储存 phi 变化的分贝图数据
                file_phi_name = sprintf('With_Phi_data_R=%dL_Omega=%d_theta0=%d_t=%0.3fT_thetaf=%0.3f.csv', beta, omega,theta0, t_factor, rad2deg(max_theta));
                file_phi_path = fullfile(result_folder, file_phi_name);
                 % 确保保存数据的文件夹存在，如果不存在则创建
                if ~isfolder(result_folder)
                 mkdir(result_folder);
                end
                % 计算 phi 变化的分贝值
                phi_degrees = linspace(0, 180, num_phi);
                dB_phi_values = zeros(size(phi_degrees));
               
                for i = 1:length(phi_degrees)
                    phi_radians = deg2rad(phi_degrees(i));
                    s_sphere_phi = S_sphere(max_theta, R, phi_radians, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
                    s_ref_phi = s_sphere_phi / max_value;
                    dB_phi_values(i) = 10 * log10(s_ref_phi);
                end
                % 保存 phi 变化的分贝值数据
                writematrix([phi_degrees' dB_phi_values'], file_phi_path);

                % 构建文件名，储存 theta 变化的分贝图数据
                file_theta_name = sprintf('With_Theta_data_R=%dL_Omega=%d_theta0=%d_t=%0.3fT_phif=%0.3f.csv', beta,omega, theta0, t_factor, rad2deg(max_phi));
                file_theta_path = fullfile(result_folder, file_theta_name);
                % 检查文件夹是否存在，如果不存在则创建
                if ~exist(result_folder, 'dir')
                 mkdir(result_folder);
                end
                % 计算 theta 变化的分贝值
                theta_degrees = linspace(0, 360, num_theta);
                dB_theta_values = zeros(size(theta_degrees));
                for i = 1:length(theta_degrees)
                    theta_radians = deg2rad(theta_degrees(i));
                    s_sphere_theta = S_sphere(theta_radians, R, max_phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
                    s_ref_theta = s_sphere_theta / max_value;
                    dB_theta_values(i) = 10 * log10(s_ref_theta);
                end

                % 保存 theta 变化的分贝值数据
                writematrix([theta_degrees' dB_theta_values'], file_theta_path);

            end
        end
    end
end

disp('数据保存完成！');
