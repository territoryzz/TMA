%F2f
function [F2f] = F2f(theta, r, z, thetaf, rf, zf)
    F2f = rf./sqrt(r.^2 + rf.^2 - 2.*r.*rf.*cos(theta-thetaf) + (z-zf).^2);
end