%lobe pattern
clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1; 
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 3;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);

%考虑绘制波瓣图，那么必须考虑在远场情况下，波长条件难以满足，故仅满足器件尺寸条件和瑞丽条件r>2*D^2/lambda
%初步选定 beta = R/L
%取t=1/4T
beta = 10;
R = beta * a;
t_factor = 1/2 ;
t_fixed =t_factor * 2*pi/omega;

%先要寻找S主峰分布的位置           

% 生成一组离散的 theta 和 phi 值
num_theta = 200;
num_phi = 100;
theta_range = linspace(0, 2*pi, num_theta);
phi_range = linspace(0, pi, num_phi);


% 初始化函数值数组
S_values_initial = zeros(num_theta, num_phi);

% 计算函数值
for i = 1:num_theta
    for j = 1:num_phi
        % 计算函数值
        S_values_initial(i, j) = S_sphere(theta_range(i), R, phi_range(j), omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
    end
end

S_values= S_values_initial;
S_values(isinf(S_values) | isnan(S_values)) = 0; % 将无效值替换为 0

save('S_values.mat', 'S_values');





% 只分析查找程序，节约一次次算 S 的时间
load('S_values.mat');



%% 找到最大值及其位置
[max_value, max_index] = max(S_values(:));
[max_row, max_col] = ind2sub(size(S_values), max_index);
max_theta = theta_range(max_row);
max_phi = phi_range(max_col);

% 将结果写入文件
fileID = fopen('max_value_theta_phi.txt', 'w');
fprintf(fileID, '最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n', max_value, max_theta, rad2deg(max_theta), max_phi, rad2deg(max_phi));
fclose(fileID);

% 显示结果
fprintf('最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n', max_value, max_theta,rad2deg(max_theta), max_phi,rad2deg(max_phi));




%% 找到半功率波束范围

% 清理数据，替换无效值
S_values_clean = S_values;
S_values_clean(isinf(S_values) | isnan(S_values)) = 0; % 将无效值替换为 0

half_max_power = 1/2 *max_value;

% 构建大于半功率的数组元素
half_power_theta_index = find(S_values(:, max_col) >= half_max_power);
if isempty(half_power_theta_index)
    error('未找到 theta 方向上的半功率点。');
end

half_power_phi_index = find(S_values(max_row, :) >= half_max_power);
if isempty(half_power_phi_index)
    error('未找到 phi 方向上的半功率点。');
end

% theta方向半功率波束宽度的计算
% 检查是否出现旁瓣
% 检查 half_power_theta_index 的连续性
is_continuous = all(diff(half_power_theta_index) == 1);

if is_continuous
    % 连续情况下计算半功率波束宽度
    hpbw_theta = max(theta_range(half_power_theta_index)) - min(theta_range(half_power_theta_index));
    theta_theta_min =  min(theta_range(half_power_theta_index));
    theta_theta_max = max(theta_range(half_power_theta_index));
else

    % 非连续情况下找到突变位置
    threshold = 2;  % 设定一个阈值，表示两个相邻元素的最小差异
    mutate_points_theta = zeros(2, 1);
    max_theta_index = find(half_power_theta_index == max_row);

    % 从最大索引向前找突变位置
    if max_theta_index > 2
    for i = max_theta_index:-1:2
        if abs(half_power_theta_index(i) - half_power_theta_index(i-1)) >= threshold 
            mutate_points_theta(1) = half_power_theta_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_theta(1) = half_power_theta_index(i);
    end
     else
        mutate_points_theta(1) = half_power_theta_index(max_theta_index); 
    end

    % 从最大索引向后找突变位置
    for i = max_theta_index:numel(half_power_theta_index)-1
        if abs(half_power_theta_index(i+1) - half_power_theta_index(i)) >= threshold
            mutate_points_theta(2) = half_power_theta_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_theta(2) = half_power_theta_index(i);
    end

    % 计算突变位置对应的 theta 范围和半功率波束宽度
    theta_theta_min = theta_range(mutate_points_theta(1));
    theta_theta_max = theta_range(mutate_points_theta(2));
    hpbw_theta = theta_theta_max - theta_theta_min;
end

% 显示结果
fprintf('波束范围为：theta 方向 %f 度 到 %f 度\n', rad2deg(theta_theta_min), rad2deg(theta_theta_max));
fprintf('半功率波束宽度为：theta 方向 %f 度\n', rad2deg(hpbw_theta));



% phi方向半功率波束宽度的计算
% 检查是否出现旁瓣
% 检查 half_power_phi_index 的连续性
is_continuous = all(diff(half_power_phi_index) == 1);

if is_continuous
    % 连续情况下计算半功率波束宽度
    hpbw_phi = max(phi_range(half_power_phi_index)) - min(phi_range(half_power_phi_index));
    phi_phi_min =  min(phi_range(half_power_phi_index));
    phi_phi_max = max(phi_range(half_power_phi_index));
else

    % 非连续情况下找到突变位置
    mutate_points_phi = zeros(2, 1);
    max_phi_index = find(half_power_phi_index == max_col);

    % 从最大索引向前找突变位置
    for i = max_phi_index:-1:2
        if abs(half_power_phi_index(i) - half_power_phi_index(i-1)) >= threshold 
            mutate_points_phi(1) = half_power_phi_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
         mutate_points_phi(1) = half_power_phi_index(i);
    end

    % 从最大索引向后找突变位置
    for i = max_phi_index:numel(half_power_phi_index)-1
        if abs(half_power_phi_index(i+1) - half_power_phi_index(i)) >= threshold
            mutate_points_phi(2) = half_power_phi_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_phi(2) = half_power_phi_index(i);
    end

    % 计算突变位置对应的 theta 范围和半功率波束宽度
    phi_phi_min = phi_range(mutate_points_phi(1));
    phi_phi_max = phi_range(mutate_points_phi(2));
    hpbw_phi = phi_phi_max - phi_phi_min;
end

% 显示结果
fprintf('波束范围为：phi 方向 %f 度 到 %f 度\n', rad2deg(phi_phi_min), rad2deg(phi_phi_max));
fprintf('半功率波束宽度为：phi 方向 %f 度\n', rad2deg(hpbw_phi));



%% 计算归一化波瓣图
S_normal = S_values / max_value;
half_max_power_normal = 0.5;

%% 绘制图像进行检查
% 绘制关于 theta 的图像
figure;
plot(rad2deg(theta_range), S_normal(:, max_col)); % 使用 rad2deg 将弧度转换为度
xlabel('Theta (degrees)');
ylabel('S');
title(['S plot at phi = ', num2str(rad2deg(phi_range(max_col))), '°']);
% 添加半功率的水平线
yline(half_max_power_normal, '--', '半功率');

% 绘制关于 phi 的图像
figure;
plot(rad2deg(phi_range), S_normal(max_row, :)); % 使用 rad2deg 将弧度转换为度
xlabel('Phi (degrees)');
ylabel('S');
title(['S plot at theta = ', num2str(rad2deg(theta_range(max_row))), '°']);
% 添加半功率的水平线
yline(half_max_power_normal, '--', '半功率');


