%球坐标下的函数
function [B_sphere] = B_sphere(R, theta, phi, t, omega, theta0, a, b, ka)
    %将柱坐标用球坐标参数表示
    r = R*sin(phi);
    z = R*cos(phi);  
    B_sphere = B(theta, r, z, omega, t, theta0, a, b, ka);
end