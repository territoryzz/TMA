%F3f
function [F3f] = F3f(theta, r, z, thetaf, rf, zf)
   F3f = rf./(r.^2 + rf.^2 -2.*r.*rf.*cos(theta-thetaf)+(z-zf).^2).^3/2;
end
