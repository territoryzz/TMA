function [F0] = F0(theta, r, z, thetaf, a, b)
    % 定义积分函数的句柄，传递场点位置 r 和 z 作为额外参数
    F0_integrand = @(rf, zf) F0f(theta, r, z, thetaf, rf, zf);
    % 执行积分计算
    F0 = integral2(F0_integrand, 0, a, 0, b);
end