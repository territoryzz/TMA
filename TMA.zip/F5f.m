%F5f
function [F5f] = F5f(theta, r, z, thetaf, rf, zf)
  F5f = rf.^2./sqrt(r.^2 + rf.^2 -2.*r.*rf.*cos(theta-thetaf)+(z-zf).^2);
end
