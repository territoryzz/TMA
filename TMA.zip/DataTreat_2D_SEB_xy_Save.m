clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30, 300, 3000, 30000];
theta0_values = [3, 30, 60, 90];
beta_values = [2, 5, 10, 20];
t_factor_values = [1/4, 1/2, 3/4, 1];
z_point_values = [-0.5, 0.05, 0.5];  % z_point 取值列表


%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values
        % 设置A，phi的计算常数
        ka = -mu * sigma * theta0 * omega / (4*pi);
        kphi2 = sigma / (4*pi*epsilon0);
        kphi1 = -sigma / (4*pi*epsilon0);

        for beta = beta_values
           r_fixed= beta * a;

            for t_factor = t_factor_values
                t_fixed = t_factor * 2*pi/omega;
                for z_fixed = z_point_values


% 再考虑绘制z=z_fixed情况下，在此平面的分布
% 定义 r 和 theta 的范围
num_theta_points = 100;
num_r_points = 100;
r_values = linspace(0, r_fixed, num_r_points);  % 例如，0 到最大 r 值，num_r_points 个点
theta_start = -pi;
theta_end = pi;
theta_values = linspace(theta_start, theta_end, num_theta_points);  % 角度从 -pi 到 pi



% 初始化 B 数值数组
B_values = zeros(num_theta_points, num_r_points);

% 循环计算 B 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r =  r_values(j);
        theta = theta_values(i);
        
        % 计算 B 的值并存储在 B_values 中
        B_values(i, j) = B(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka);
    end
end

% 初始化 E 数值数组
E_values = zeros(num_theta_points, num_r_points);

% 循环计算 E 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r = r_values(j);
        theta = theta_values(i);
        
        % 计算 E 的值并存储在 E_values 中
        E_values(i, j) = E(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
    end
end

% 初始化 S 数值数组
S_values = zeros(num_theta_points, num_r_points);

% 循环计算 E 的值
for i = 1:num_theta_points
    for j = 1:num_r_points
        % 获取当前 r 和 theta 值
        r =  r_values(j);
        theta = theta_values(i);
        
        % 计算 E 的值并存储在 E_values 中
        S_values(i, j) = S(theta, r, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
    end
end


% 转换为笛卡尔坐标
[R, Theta] = meshgrid(r_values, theta_values);
X = R .* cos(Theta);
Y = R .* sin(Theta);

 B_values(isinf(B_values) | isnan(B_values)) = 0; % 将无效值替换为 0

 E_values(isinf(E_values) | isnan(E_values)) = 0; % 将无效值替换为 0

 S_values(isinf(S_values) | isnan(S_values)) = 0; % 将无效值替换为 0

% 构建文件名
file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/2D_Field_xy/data_r=%.2f_theta0=%d_Omega=%d_t=%.2fT_z=%.2f.csv', r_fixed, theta0,omega,t_factor, z_fixed);

% 检查文件夹是否存在，如果不存在则创建
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/2D_Field_xy/';
if ~exist(folder_path, 'dir')
    mkdir(folder_path);
end  

% 构建要保存的数据矩阵
data = [X(:), Y(:),B_values(:),E_values(:), S_values(:)];
             
% 保存数据到 CSV 文件
writematrix(data, file_name);
                
                end
            end
        end
    end
end




disp('数据保存完成！');