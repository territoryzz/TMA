clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);


%% 选取点（0.15, 30°, 0.5）做随时间变换的图像
r_point = 0.15;
thetaAng=30;
theta_point = deg2rad(thetaAng); % 将角度转换为弧度
z_point = 0.5;

% 时间向量
t = linspace(0, 3*2*pi/omega, 100); % 假设三个周期的波

% 绘制极板运动作为参考
figure; % 创建新的图形窗口
Theta2_values=Theta2(omega,t,theta0);
plot(t, Theta2_values);
xlabel('时间');
ylabel('Theta2');
title('Theta2随时间变化');

thetaf = Theta2(omega,t,theta0); % theta2函数内完成了将角度值转换为弧度制的过程

% 绘制B、E、S大小随时间变化的图
E_values = zeros(size(t));
Er_values = zeros(size(t));
Etheta_values = zeros(size(t));
Ez_values = zeros(size(t));
F2_values = zeros(size(t));
F31_values = zeros(size(t));
F32_values = zeros(size(t));
F4_values = zeros(size(t));

for i = 1:length(t)
    E_values(i) = E(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2);
    Er_values(i) = Er(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2);
    Etheta_values(i) = Etheta(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2);
    Ez_values(i) = Ez(theta_point, r_point,z_point, omega, t(i), theta0, a, b, kphi1, kphi2);
    theta2 = Theta2(omega,t(i),theta0);
    F2_values(i) = F2(theta_point, r_point, z_point, theta2, a ,b);
    F31_values(i) = F3(theta_point, r_point, z_point, 0, a ,b);
    F32_values(i) = F3(theta_point, r_point, z_point, theta2, a, b);
    F4_values(i) = F2(theta_point, r_point, z_point, theta2, a, b);
end

figure;
plot(t,  E_values);
xlabel('时间');
ylabel(' Er');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 E 的大小']);
grid on;

figure;
plot(t,  Er_values);
xlabel('时间');
ylabel(' Er');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 Er 的大小']);
grid on;

figure;
plot(t,  Etheta_values);
xlabel('时间');
ylabel(' Etheta');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 Etheta 的大小']);
grid on;

figure;
plot(t,  Ez_values);
xlabel('时间');
ylabel(' Ez');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 Ez 的大小']);
grid on;

figure;
plot(t, F2_values);
xlabel('时间');
ylabel(' F2');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 F2 的大小']);
grid on;

figure;
plot(t, F31_values);
xlabel('时间');
ylabel(' F31');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 F31 的大小']);
grid on;

figure;
plot(t, F32_values);
xlabel('时间');
ylabel(' F32');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 F32 的大小']);
grid on;

figure;
plot(t, F4_values);
xlabel('时间');
ylabel(' F4');
title(['固定点（0.15, theta = ', num2str(thetaAng), '°, 0.15）随时间变化的 F4 的大小']);
grid on;
