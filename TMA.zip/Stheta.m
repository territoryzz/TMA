%Stheta
function [Stheta] = Stheta(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2, mu)
Stheta = 1/mu*(Ez(theta, r, z, omega, t, theta0, a, b, kphi1, kphi2).*Br(theta, r, z, omega, t, theta0, a, b, ka) - ...
    Er(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2).*Bz(theta, r, z, omega, t, theta0, a, b, ka));
end