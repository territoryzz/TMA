function [F0f] = F0f(theta, r, z, thetaf, rf, zf)    
    F0f = 1./sqrt(r.^2 + rf.^2 - 2*r.*rf.*cos(theta-thetaf)+(z-zf).^2) ;
end