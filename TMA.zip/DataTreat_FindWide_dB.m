%lobe pattern
clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);


% 打开文件以读取
fileID = fopen('max_value_theta_phi.txt', 'r');
% 读取文件中的数据
data = fscanf(fileID, '最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n');
% 关闭文件
fclose(fileID);

% 提取数据
max_value = data(1);
max_theta = data(2);
max_theta_deg = data(3);
max_phi = data(4);
max_phi_deg = data(5);

% 显示结果
fprintf('最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n', max_value, max_theta,max_theta_deg,max_phi, max_phi_deg);



%初步选定 R = 0.25
%取t=1/4T
R = 0.25;
t_fixed =1/4 * 2*pi/omega;


%% 绘制theta = theta_max下的分贝图
% 定义要绘制的 phi 范围（以度为单位）
phi_degrees = linspace(0, 180, 100); % 修改为您希望的 phi 范围（以度为单位）

% 创建存储 phi 和分贝值的数组
phi_values = zeros(size(phi_degrees));
dB_phi_values = zeros(size(phi_degrees));

% 循环计算每个 phi 对应的分贝值
for i = 1:length(phi_degrees)
    % 计算当前 phi 对应的分贝值
    phi_radians = deg2rad(phi_degrees(i)); % 将角度转换为弧度
    s_sphere_phi = S_sphere(max_theta, R, phi_radians, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu); % 使用最大值作为参考功率值
    s_ref_phi = s_sphere_phi/max_value;
    dB = 10 * log10(s_ref_phi); % 计算分贝值
    
    % 存储 phi 和分贝值
    phi_values(i) = phi_degrees(i);
    dB_phi_values(i) = dB;
end

% 绘制分贝图（使用平滑的线）
figure;
plot(phi_values, dB_phi_values);

% 添加 -3dB 的水平线
yline(-3, '--', '-3 dB');

% 添加标签和标题
xlabel('Phi (degrees)');
ylabel('S (dB)');
title(['S dB plot at max theta = ', num2str(max_theta_deg), '°']);




%% 绘制phi = phi_max下的分贝图
% 定义要绘制的 theta 范围（以度为单位）
theta_degrees = linspace(0, 360, 100); % 修改为您希望的 theta 范围（以度为单位）

% 创建存储 theta 和分贝值的数组
theta_values = zeros(size(theta_degrees));
dB_theta_values = zeros(size(theta_degrees));

% 循环计算每个 theta 对应的分贝值
for i = 1:length(theta_degrees)
    % 计算当前 theta 对应的分贝值
    theta_radians = deg2rad(theta_degrees(i)); % 将角度转换为弧度
    s_sphere_theta = S_sphere(theta_radians, R, max_phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu); % 使用最大值作为参考功率值
    s_ref_theta = s_sphere_theta/max_value;
    dB = 10 * log10(s_ref_theta); % 计算分贝值
    
    % 存储 phi 和分贝值
    theta_values(i) = theta_degrees(i);
    dB_theta_values(i) = dB;
end

% 绘制分贝图（使用平滑的线）
figure;
plot(theta_values, dB_theta_values);

% 添加 -3dB 的水平线
yline(-3, '--', '-3 dB');

% 添加标签和标题
xlabel('Theta (degrees)');
ylabel('S (dB)');
title(['S dB plot at max phi = ', num2str(max_phi_deg), '°']);



%% 在theta = theta_max平面上与在phi = phi_max平面上，寻找波束范围，即-3dB处
half_max_power = -3;
half_power_theta_index = find(dB_theta_values >= half_max_power);
half_power_phi_index = find(dB_phi_values>= half_max_power);

% 检查是否找到了半功率点
if isempty(half_power_theta_index) || isempty(half_power_phi_index)
    error('未找到半功率点。');
end

% 计算半功率波束宽度和波束范围
half_power_theta_values = theta_degrees(half_power_theta_index);
half_power_phi_values = phi_degrees(half_power_phi_index);

% 找到超过半功率阈值的角度范围
theta_hpbw_indices = find(dB_theta_values >= half_max_power);
phi_hpbw_indices = find(dB_phi_values >= half_max_power);

% 计算角度范围的平均值，得到波束范围
hpbw_theta = theta_degrees(theta_hpbw_indices(end)) - theta_degrees(theta_hpbw_indices(1));
hpbw_phi =  phi_degrees(phi_hpbw_indices(end)) -  phi_degrees(phi_hpbw_indices(1));


% 显示结果
fprintf('波束范围为：theta 方向 %f 度 到 %f 度\n', theta_degrees(theta_hpbw_indices(1)), theta_degrees(theta_hpbw_indices(end)));
fprintf('波束范围为：phi 方向 %f 度 到 %f 度\n', phi_degrees(phi_hpbw_indices(1)), phi_degrees(phi_hpbw_indices(end)));
fprintf('波束范围为：theta 方向 %f 度，phi 方向 %f 度\n', hpbw_theta, hpbw_phi);



