clear;
close all;
clc;

% 定义新的文件夹路径
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S_R/';
save_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/Test_Supplementary/';

% 设定参数
omega = 30;
theta0 = 3;
t_factor = 1/4;
beta_values = [12, 13, 14, 15, 16, 17, 19, 20, 30];

% 定义 theta 和 phi 范围
num_theta = 360;
num_phi = 180;
theta_range = linspace(0, 2*pi, num_theta);
phi_range = linspace(0, pi, num_phi);

% 创建网格
[Theta, Phi] = meshgrid(theta_range, phi_range);

% 循环绘制每个 beta 的独立图像，并统一颜色映射
for i = 1:length(beta_values)
    beta = beta_values(i);
    file_name = sprintf('S_values_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.mat', omega, theta0, beta, t_factor);
    data = load(fullfile(folder_path, file_name));
    S_values_clean = data.S_values_clean;
    [max_value, ~] = max(S_values_clean(:));

    S_values_normalized = S_values_clean / max_value;

    % 创建新图像
    figure;
    surf(Theta, Phi, S_values_normalized', 'EdgeColor', 'none'); % 这里转置矩阵，使其匹配网格
    colorbar; % 添加颜色条
    caxis([0, 1]); % 统一颜色映射
    title(sprintf('S Values (omega=%d, theta0=%d, beta=%d, t-factor=%0.3f)', omega, theta0, beta, t_factor));
    xlabel('\theta');
    ylabel('\phi');
    zlabel('S');
    view(2); % 从上方查看平面图
    axis tight;

    % 设置 Theta 方向刻度
    set(gca, 'XTick', linspace(0, 2*pi, 7)); % 设置 X 轴刻度为 0, 60, 120, 180, 240, 300, 360
    set(gca, 'XTickLabel', {'0', '60', '120', '180', '240', '300', '360'}); % 设置 X 轴刻度标签

    % 设置 Phi 方向刻度
    set(gca, 'YTick', linspace(0, pi, 7)); % 设置 Y 轴刻度为 0, 30, 60, 90, 120, 150, 180
    set(gca, 'YTickLabel', {'0', '30', '60', '90', '120', '150', '180'}); % 设置 Y 轴刻度标签

    % 更改颜色映射为 jet
    colormap('jet'); % 使用 jet 色图

    % 设置透明背景
    set(gcf, 'Color', 'none');
    set(gca, 'Color', 'none');

    saveas(gcf, fullfile(save_path, sprintf('S_plot_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.png', omega, theta0, beta, t_factor)));

    % 保存图像为 EPS 格式（适合在 Illustrator 中编辑）
    saveas(gcf, fullfile(save_path, sprintf('S_plot_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.eps', omega, theta0, beta, t_factor)), 'epsc');

   % 保存图像为 SVG 格式（适合在 Illustrator 中编辑）
   print(fullfile(save_path, sprintf('S_plot_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.svg', omega, theta0, beta, t_factor)), '-dsvg');

end

disp('所有图像生成完成并保存到新地址，并使用统一的颜色映射！');


