%球坐标下的函数
function [E_sphere] = E_sphere(theta, R, phi, omega, t, theta0, a, b, ka, kphi1, kphi2)
    %将柱坐标用球坐标参数表示
    r = R*sin(phi);
    z = R*cos(phi);  
    E_sphere = E(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2);
end