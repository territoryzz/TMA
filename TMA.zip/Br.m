%Br
function [Br] = Br(theta, r, z, omega, t, theta0, a, b, ka)
thetaf=Theta2(omega,t,theta0);
Br = ka*sin(omega*t).*cos(thetaf-theta).*F7(theta, r, z, thetaf, a, b);
end
