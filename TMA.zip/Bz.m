%Bz
function [Bz] = Bz(theta, r, z, omega, t, theta0, a, b, ka)
thetaf=Theta2(omega,t,theta0);
Bz1 = ka*sin(omega*t).*cos(thetaf-theta)*(1./r *F2(theta, r, z, thetaf, a, b)-r.*F3(theta, r, z, thetaf, a, b)+cos(theta-thetaf).*F4(theta, r, z, thetaf, a, b));
Bz2=ka*sin(omega*t)./r.*(-cos(thetaf-theta).*F2(theta, r, z, thetaf, a, b)-sin(thetaf-theta).*r.*sin(theta-thetaf).*F4(theta, r, z, thetaf, a, b));
Bz = Bz1+Bz2;
end