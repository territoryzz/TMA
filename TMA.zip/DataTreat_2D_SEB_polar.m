clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);




%% 考虑选取t=1/4T时，绘制z=z_fixed处,r=r_fixed的极坐标下的分布
t_factor = 1/4 ;
t_fixed =t_factor * 2*pi/omega;
z_fixed = 0.5;
r_fixed = 0.5;

% 定义 theta 范围
theta = linspace(0, 2*pi, 100);

% 计算对应位置的场强大小 B
B_values = zeros(size(theta));
for i = 1:numel(theta)
    B_values(i) = B(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka);
end

% 归一化场强大小到 [0, 1] 的范围
B_values_normalized = B_values / max(B_values);

% 绘制归一化后的极坐标波束图
figure;
polarplot(theta(:), B_values_normalized(:));
title(['极坐标下归一化B  (r = ', num2str(r_fixed), ', z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);


% 计算对应位置的场强大小 E
E_values = zeros(size(theta));
for i = 1:numel(theta)
    E_values(i) = E(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
end

% 归一化场强大小到 [0, 1] 的范围
E_values_normalized = E_values / max(E_values);

% 绘制归一化后的极坐标波束图
figure;
polarplot(theta(:), E_values_normalized(:));
title(['极坐标下归一化E  (r = ', num2str(r_fixed), ', z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);


% 计算对应位置的场强大小 S
S_values = zeros(size(theta));
for i = 1:numel(theta)
    S_values(i) = S(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
end

% 归一化场强大小到 [0, 1] 的范围
S_values_normalized = S_values / max(S_values);

% 绘制归一化后的极坐标波束图
figure;
polarplot(theta(:), S_values_normalized(:));
title(['极坐标下归一化S  (r = ', num2str(r_fixed), ', z = ', num2str(z_fixed), ', t = ', num2str(t_fixed), ')']);



% %% 保存数据并在origin中画图
% 
% % 构建文件名
% file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/2D_Field_polar/data_r=%.2f_theta0=%d_t=%.2fT_z=%.2f.csv', r_fixed, theta0,t_factor, z_fixed);
% 
% % 检查文件夹是否存在，如果不存在则创建
% folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/2D_Field_polar/';
% if ~exist(folder_path, 'dir')
%     mkdir(folder_path);
% end  
% 
% % 构建要保存的数据矩阵
% data = [theta', B_values_normalized', E_values_normalized', S_values_normalized'];
%             
% % 保存数据到 CSV 文件
% writematrix(data, file_name);


