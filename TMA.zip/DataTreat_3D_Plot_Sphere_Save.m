clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30, 300, 3000, 30000];
theta0_values = [3, 30, 60, 90];
beta_values = [2, 5, 10, 20];
t_factor_values = [1/4, 1/2, 3/4, 1];


%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values
        % 设置A，phi的计算常数
        ka = -mu * sigma * theta0 * omega / (4*pi);
        kphi2 = sigma / (4*pi*epsilon0);
        kphi1 = -sigma / (4*pi*epsilon0);

        for beta = beta_values
           R= beta * a;

            for t_factor = t_factor_values
                t_fixed = t_factor * 2*pi/omega;
               


% 定义网格点数量
num_theta = 361; % 对应于角度范围 eps 到 2*pi，步长为 2*pi/180
num_phi = 181; % 对应于角度范围 eps 到 pi，步长为 pi/180

% 初始化笛卡尔坐标
x = zeros(num_phi, num_theta);
y = zeros(num_phi, num_theta);
z = zeros(num_phi, num_theta);

% 计算磁场值
B = zeros(num_phi, num_theta);
E = zeros(num_phi, num_theta);
S = zeros(num_phi, num_theta);
for i = 1:num_theta
    for j = 1:num_phi
        % 计算球坐标下的角度
        theta = (i - 1) * 2 * pi / 180; % 角度从 0 到 2pi
        phi = (j - 1) * pi / 180; % 角度从 0 到 pi
        
        % 计算磁场值
        B(j, i) = B_sphere(R, theta, phi, t_fixed, omega, theta0, a, b, ka);
        E(j, i) = E_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
        S(j, i) = S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
        
        % 将球坐标转换为笛卡尔坐标
        %[x, y, z] = sph2cart(theta, phi, r) 
        % r为极径
        % theta 是极角，以弧度表示，范围通常是[0,2π]
        % phi 为方位角，以弧度表示，范围通常是[0,π)
        %需要特别注意，我定义的theta与phi和标准定义下的theta和phi是刚好相反的
        [x(j, i), y(j, i), z(j, i)] = sph2cart(theta ,phi , R);
    end
end

% 归一化处理
B_normalized = B / max(B(:)); % 将磁场值归一化到 [0, 1] 的范围
E_normalized = E / max(E(:)); % 
S_normalized = S / max(S(:)); %
               
% 构建文件名
file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/3D_Field_normalized_Sphere/data_R=%dL_theta0=%d_Omega=%d_t=%.2fT.csv',beta, theta0,omega, t_factor);

% 检查文件夹是否存在，如果不存在则创建
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/3D_Field_normalized_Sphere/';
if ~exist(folder_path, 'dir')
    mkdir(folder_path);
end  

% 构建要保存的数据矩阵
data = [x(:), y(:),z(:),B_normalized(:),E_normalized(:), S_normalized(:)];
             
% 保存数据到 CSV 文件
writematrix(data, file_name);


            end
        end
    end
end




disp('数据保存完成！');