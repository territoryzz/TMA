%F4f
function [F4f] = F4f(theta, r, z, thetaf, rf, zf)
   F4f = rf.^2./(r.^2 + rf.^2 - 2.*r.*rf.*cos(theta-thetaf) + (z-zf).^2).^3/2;
end
