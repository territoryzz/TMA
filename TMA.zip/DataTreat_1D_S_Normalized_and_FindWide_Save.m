clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30];
theta0_values = [3, 30, 60, 90];
beta_values = [2, 3, 4, 5, 6, 7, 8, 9, 10 , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 40 ,50];
t_factor_values = [1/12, 1/6, 1/4, 1/3, 5/12, 1/2 ];

%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values
        % 设置A，phi的计算常数
        ka = -mu * sigma * theta0 * omega / (4*pi);
        kphi2 = sigma / (4*pi*epsilon0);
        kphi1 = -sigma / (4*pi*epsilon0);

        % 确定 thetafAng 的取值
        thetafAng_values = [theta0, -theta0, 3*theta0];
        for beta = beta_values
            R = beta * a;

            for t_factor = t_factor_values
                t_fixed = t_factor * 2*pi/omega;

                    % 生成一组离散的 theta 和 phi 值
                    num_theta = 360;
                    num_phi = 180;
                    theta_range = linspace(0, 2*pi, num_theta);
                    phi_range = linspace(0, pi, num_phi);






%                     % 初始化 S_values_initial 数组
%                     S_values_initial = zeros(num_theta, num_phi);
% 
%                     % 计算 S_values_initial
%                     for i = 1:num_theta
%                         for j = 1:num_phi
%                             S_values_initial(i, j) = S_sphere(theta_range(i), R, phi_range(j), omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
%                         end
%                     end
% 
% % 清理数据，替换无效值
% S_values_clean = S_values_initial;
% S_values_clean(isinf(S_values_initial) | isnan(S_values_initial)) = 0; % 将无效值替换为 0
% 
% 
% % 保存 S_values_initial 到文件夹 S 中
% folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S/';
% if ~exist(folder_path, 'dir')
% mkdir(folder_path);
% end
% file_name = sprintf('S_values_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.mat', omega, theta0, beta, t_factor);
% save(fullfile(folder_path, file_name), 'S_values_clean');
% 
% % 找到最大值及其位置
% [max_value, max_index] = max(S_values_clean(:));
% [max_row, max_col] = ind2sub(size(S_values_clean), max_index);
% max_theta = theta_range(max_row);
% max_phi = phi_range(max_col);
% 
% % 构建文件名，体现参数取值
% file_name = sprintf('max_value_theta_phi_omega=%d_theta0=%d_beta=%d_t=%.3fT.txt', omega, theta0, beta, t_factor);
% 
% % 将结果写入文件夹 S 中的文本文件
% fileID = fopen(fullfile(folder_path, file_name), 'a');
% fprintf(fileID, 'omega=%d, theta0=%d, beta=%d, t=%.3fT:\n', omega, theta0, beta, t_factor);
% fprintf(fileID, '最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n\n', max_value, max_theta, rad2deg(max_theta), max_phi, rad2deg(max_phi));
% fclose(fileID);
% 
% 
%  %% 找到半功率波束范围
% 
% half_max_power = 1/2 * max_value;
% 
% % 构建大于半功率的数组元素
% half_power_theta_index = find(S_values_clean(:, max_col) >= half_max_power);
% if isempty(half_power_theta_index)
%     error('未找到 theta 方向上的半功率点。');
% end
% 
% half_power_phi_index = find(S_values_clean(max_row, :) >= half_max_power);
% if isempty(half_power_phi_index)
%     error('未找到 phi 方向上的半功率点。');
% end
% 
% % theta方向半功率波束宽度的计算
% is_continuous_theta = all(diff(half_power_theta_index) == 1);
% 
% if is_continuous_theta
%     % 连续情况下计算半功率波束宽度
%     hpbw_theta = max(theta_range(half_power_theta_index)) - min(theta_range(half_power_theta_index));
%     theta_theta_min = min(theta_range(half_power_theta_index));
%     theta_theta_max = max(theta_range(half_power_theta_index));
% else
%     % 非连续情况下找到突变位置
%     threshold = 2;  % 设定一个阈值，表示两个相邻元素的最小差异
%     mutate_points_theta = zeros(2, 1);
%     max_theta_index = find(half_power_theta_index == max_row);
% 
%     % 从最大索引向前找突变位置
%     if 2 < max_theta_index && max_theta_index < max(theta_range(half_power_theta_index))
%     for i = max_theta_index:-1:2
%         if abs(half_power_theta_index(i) - half_power_theta_index(i-1)) >= threshold
%             mutate_points_theta(1) = half_power_theta_index(i);
%             break;  % 找到第一个突变位置就退出循环
%         else
%             mutate_points_theta(1) = half_power_theta_index(i);
%         end
%     end
%     else
%     mutate_points_theta(1) = half_power_theta_index(max_theta_index); 
%     end
% 
%     % 从最大索引向后找突变位置
%     if 2 < max_theta_index && max_theta_index < max(theta_range(half_power_theta_index))
%     for i = max_theta_index:numel(half_power_theta_index)-1
%         if abs(half_power_theta_index(i+1) - half_power_theta_index(i)) >= threshold
%             mutate_points_theta(2) = half_power_theta_index(i);
%             break;  % 找到第一个突变位置就退出循环
%         end
%         mutate_points_theta(2) = half_power_theta_index(i);
%     end
%         else
%         mutate_points_theta(2) = half_power_theta_index(max_theta_index); 
%     end
% 
% 
% 
%     % 计算突变位置对应的 theta 范围和半功率波束宽度
%     theta_theta_min = theta_range(mutate_points_theta(1));
%     theta_theta_max = theta_range(mutate_points_theta(2));
%     hpbw_theta = theta_theta_max - theta_theta_min;
% end
% 
% % phi方向半功率波束宽度的计算
% is_continuous_phi = all(diff(half_power_phi_index) == 1);
% 
% if is_continuous_phi
%     % 连续情况下计算半功率波束宽度
%     hpbw_phi = max(phi_range(half_power_phi_index)) - min(phi_range(half_power_phi_index));
%     phi_phi_min = min(phi_range(half_power_phi_index));
%     phi_phi_max = max(phi_range(half_power_phi_index));
% else
%     % 非连续情况下找到突变位置
%     mutate_points_phi = zeros(2, 1);
%     max_phi_index = find(half_power_phi_index == max_col);
% 
%     % 从最大索引向前找突变位置
%     if 2 < max_phi_index && max_phi_index < max(phi_range(half_power_phi_index))
%     for i = max_phi_index:-1:2
%         if abs(half_power_phi_index(i) - half_power_phi_index(i-1)) >= threshold
%             mutate_points_phi(1) = half_power_phi_index(i);
%             break;  % 找到第一个突变位置就退出循环
%         end
%         mutate_points_phi(1) = half_power_phi_index(i);
%     end
%     else
%         mutate_points_phi(1) = half_power_phi_index(max_phi_index); 
%     end
% 
%     % 从最大索引向后找突变位置
%     if 2 < max_phi_index && max_phi_index < max(phi_range(half_power_phi_index))
%     for i = max_phi_index:numel(half_power_phi_index)-1
%         if abs(half_power_phi_index(i+1) - half_power_phi_index(i)) >= threshold
%             mutate_points_phi(2) = half_power_phi_index(i);
%             break;  % 找到第一个突变位置就退出循环
%         end
%         mutate_points_phi(2) = half_power_phi_index(i);
%     end
%         else
%         mutate_points_phi(2) = half_power_phi_index(max_phi_index); 
%     end
% 
% 
%     % 计算突变位置对应的 phi 范围和半功率波束宽度
%     phi_phi_min = phi_range(mutate_points_phi(1));
%     phi_phi_max = phi_range(mutate_points_phi(2));
%     hpbw_phi = phi_phi_max - phi_phi_min;
% end
% 
% % 保存半功率波束范围结果到文件夹 S 中的文本文件
% folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_Normalized/hpbw/';
% if ~exist(folder_path, 'dir')
%     mkdir(folder_path);
% end
% file_name = sprintf('hpbw_results_omega=%d_theta0=%d_beta=%d_t=%.3fT.txt', omega, theta0, beta, t_factor);
% fileID = fopen(fullfile(folder_path, file_name), 'w');
% fprintf(fileID, '波束范围为：theta 方向 %f 度 到 %f 度\n', rad2deg(theta_theta_min), rad2deg(theta_theta_max));
% fprintf(fileID, '半功率波束宽度为：theta 方向 %f 度\n\n', rad2deg(hpbw_theta));
% fprintf(fileID, '波束范围为：phi 方向 %f 度 到 %f 度\n', rad2deg(phi_phi_min), rad2deg(phi_phi_max));
% fprintf(fileID, '半功率波束宽度为：phi 方向 %f 度\n', rad2deg(hpbw_phi));
% fclose(fileID); 


%% 保存图像数据以便在origin中画图
% 构建要读取的 S_values 文件名
S_file_name = sprintf('S_values_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.mat', omega, theta0, beta, t_factor);

% 指定 S_values 文件夹路径
S_folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S_R';


% 构建完整的文件路径
S_file_path = fullfile(S_folder_path, S_file_name);

% 加载 S_values 数组
loaded_data = load(S_file_path);
S_values_clean = loaded_data.S_values_clean;

% 找到最大值及其位置，排除在 phi = 0 或 pi 和 theta = 0 或 2*pi 的情况
S_values_masked = S_values_clean;
S_values_masked(:, [1, end]) = -Inf; % Mask phi = 0 and phi = pi
 S_values_masked([1, end], :) = -Inf; % Mask theta = 0 and theta = 2*pi

[max_value, max_index] = max(S_values_masked(:));
[max_row, max_col] = ind2sub(size(S_values_masked), max_index);
max_theta = theta_range(max_row);
  max_phi = phi_range(max_col);


% 构建文件名,储存phi变化的
file_phi_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_Original/With_Phi/data_R=%dL_Omega=%d_theta0=%d_t=%0.3fT_thetaf=%0.3f.csv', beta,omega, theta0,t_factor,rad2deg(theta_range(max_row)) );

% 检查文件夹是否存在，如果不存在则创建
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_Original/With_Phi/';
if ~exist(folder_path, 'dir')
    mkdir(folder_path);
end  

S_original = S_values_clean ;

% 构建要保存的数据矩阵
data = [rad2deg(phi_range)', S_original(max_row, :)'];
            
% 保存数据到 CSV 文件
writematrix(data, file_phi_name);


% 构建文件名,储存theta变化的
file_theta_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_Original/With_Theta/data_R=%dL_Omega=%d_theta0=%d_t=%0.3fT_phif=%0.3f.csv', beta,omega, theta0,t_factor,rad2deg(phi_range(max_col)));

% 检查文件夹是否存在，如果不存在则创建
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_Original/With_Theta/';
if ~exist(folder_path, 'dir')
    mkdir(folder_path);
end  

% 构建要保存的数据矩阵
data = [rad2deg(theta_range)', S_original(:, max_col)];
            
% 保存数据到 CSV 文件
writematrix(data, file_theta_name);


            end
        end
    end
end

disp('数据保存完成！');