%Theta2
function [Theta2] = Theta2(omega,t,theta0)
Theta2Ang = theta0 + theta0*cos(omega*t);
Theta2 = deg2rad(Theta2Ang);
end
