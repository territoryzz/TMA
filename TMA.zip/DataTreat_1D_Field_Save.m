clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
omega_values = [30, 300, 3000, 30000];  % omega 取值列表
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;
theta0_values = [3, 30, 60, 90];  % theta0 取值列表
r_point_values = [0.2, 0.5, 1.0, 2.0];  % r_point 取值列表
z_point_values = [-0.5, 0.05, 0.5];  % z_point 取值列表



%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values

        % 设置A，phi的计算常数
       ka=-mu*sigma*theta0*omega/(4*pi);
       kphi2=sigma/(4*pi*epsilon0);
       kphi1=-sigma/(4*pi*epsilon0);

        % 确定 thetafAng 的取值
        thetafAng_values = [theta0, -theta0, 3*theta0];
        
        for thetafAng = thetafAng_values
            for r_point = r_point_values
                for z_point = z_point_values
                    % 选取固定点随时间变换的图像
                    thetaf_point = deg2rad(thetafAng);  % 将角度转换为弧度

                    % 时间向量
                    t = linspace(0, 3*2*pi/omega, 200); % 假设三个周期的波

                    % 计算 Theta2
                    Theta2_values=rad2deg(Theta2(omega,t,theta0));

                    % 计算 B、E、S
                    B_values = zeros(size(t));
                    E_values = zeros(size(t));
                    S_values = zeros(size(t));

                    for i = 1:length(t)
                    B_values(i) = B(thetaf_point, r_point,z_point, omega, t(i), theta0, a, b, ka);
                    E_values(i) = E(thetaf_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2);
                    S_values(i) = S(thetaf_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2, mu);
                    end

                    % 构建文件名
                    file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_Field_With_T/data_r=%.2f_theta0=%d_thetaf=%d_z=%.2f_omega=%d.csv', r_point, theta0, thetafAng, z_point, omega);

                    % 确保文件夹存在，如果不存在则创建
                    folder_path = fileparts(file_name);
                    if ~exist(folder_path, 'dir')
                        mkdir(folder_path);
                    end

                    % 构建要保存的数据矩阵
                    data = [t', Theta2_values', B_values', E_values', S_values'];

                    % 保存数据到 CSV 文件
                    writematrix(data, file_name);
                end
            end
        end
    end
end

disp('数据保存完成！');