%Sz
function [Sz] = Sz(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2, mu)
Sz = 1/mu*(Er(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2).*Btheta(theta, r, z, omega, t, theta0, a, b, ka) - ...
    Etheta(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2).*Br(theta, r, z, omega, t, theta0, a, b, ka));
end