clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30];
beta_values = [2, 3, 4, 5, 6, 7, 8, 9, 10 , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 40 ,50];
t_factor_values = [1/12, 1/6, 1/4, 1/3, 5/12, 1/2];
theta0_values = [3, 30, 60, 90];

%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values
        % 设置A，phi的计算常数
        ka = -mu * sigma * theta0 * omega / (4*pi);
        kphi2 = sigma / (4*pi*epsilon0);
        kphi1 = -sigma / (4*pi*epsilon0);

        % 确定 thetafAng 的取值
        thetafAng_values = [theta0, -theta0, 3*theta0];
        for beta = beta_values
            R = beta * a;

            for t_factor = t_factor_values
                t_fixed = t_factor * 2*pi/omega;


                    % 生成一组离散的 theta 和 phi 值
                    num_theta = 360;
                    num_phi = 180;
                    theta_range = linspace(0, 2*pi, num_theta);
                    phi_range = linspace(0, pi, num_phi);

                    % 初始化 S_values_initial 数组
                    S_values_initial = zeros(num_theta, num_phi);

                    % 计算 S_values_initial
                    for i = 1:num_theta
                        for j = 1:num_phi
                            S_values_initial(i, j) = S_sphere(theta_range(i), R, phi_range(j), omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
                        end
                    end

% 清理数据，替换无效值
S_values_clean = S_values_initial;
S_values_clean(isinf(S_values_initial) | isnan(S_values_initial)) = 0; % 将无效值替换为 0


% 保存 S_values_initial 到文件夹 S 中
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S_R/';
if ~exist(folder_path, 'dir')
mkdir(folder_path);
end
file_name = sprintf('S_values_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.mat', omega, theta0, beta, t_factor);
save(fullfile(folder_path, file_name), 'S_values_clean');


            end
        end
    end
end

disp('数据保存完成！');