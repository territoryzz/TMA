clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30];
theta0_values = [3, 30, 60, 90];
beta_values = [2, 3, 4, 5, 6, 7, 8, 9, 10 , 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 30, 40 ,50];
t_factor_values = [1/12, 1/6, 1/4, 1/3, 5/12, 1/2 ];

% 初始化保存最大值和相关参数的结果矩阵
result_matrix = [];

%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values
        % 设置A，phi的计算常数
        ka = -mu * sigma * theta0 * omega / (4*pi);
        kphi2 = sigma / (4*pi*epsilon0);
        kphi1 = -sigma / (4*pi*epsilon0);

        % 确定 thetafAng 的取值
        thetafAng_values = [theta0, -theta0, 3*theta0];
        for beta = beta_values
            R = beta * a;

            for t_factor = t_factor_values
                t_fixed = t_factor * 2*pi/omega;

                % 生成一组离散的 theta 和 phi 值
                num_theta = 360;
                num_phi = 180;
                theta_range = linspace(0, 2*pi, num_theta);
                phi_range = linspace(0, pi, num_phi);

                %% 保存图像数据以便在origin中画图
                % 构建要读取的 S_values 文件名
                S_file_name = sprintf('S_values_omega=%d_theta0=%d_beta=%d_tfactor=%0.3f.mat', omega, theta0, beta, t_factor);

                % 指定 S_values 文件夹路径
                S_folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/S_R';

                % 构建完整的文件路径
                S_file_path = fullfile(S_folder_path, S_file_name);

                % 加载 S_values 数组
                loaded_data = load(S_file_path);
                S_values_clean = loaded_data.S_values_clean;

                % 找到最大值及其位置，排除在 phi = 0 或 pi 和 theta = 0 或 2*pi 的情况
                S_values_masked = S_values_clean;
                S_values_masked(:, [1, end]) = -Inf; % Mask phi = 0 and phi = pi
                S_values_masked([1, end], :) = -Inf; % Mask theta = 0 and theta = 2*pi

                [max_value, max_index] = max(S_values_masked(:));
                [max_row, max_col] = ind2sub(size(S_values_masked), max_index);
                max_theta = theta_range(max_row);
                max_phi = phi_range(max_col);

                % 将最大值和对应的参数保存到结果矩阵
                result_matrix = [result_matrix; omega, theta0, beta, t_factor, max_value, max_theta, max_phi];

            end
        end
    end
end

% 保存所有最大值及其参数的矩阵到 CSV 文件
result_file_name = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/Supplementary/max_S_values.csv';
writematrix(result_matrix, result_file_name);

disp('数据保存完成！');
