%Sr
function [Sr] = Sr(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2, mu)
Sr = 1/mu*(Etheta(theta, r, z, omega, t, theta0, a, b, ka, kphi1, kphi2).*Bz(theta, r, z, omega, t, theta0, a, b, ka) - ...
    Ez(theta, r, z, omega, t, theta0, a, b, kphi1, kphi2).*Btheta(theta, r, z, omega, t, theta0, a, b, ka));
end