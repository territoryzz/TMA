%F5
function [F5] = F5(theta, r, z, thetaf, a, b)
    % 定义积分函数的句柄，传递场点位置 r 和 z 作为额外参数
    F5_integrand = @(rf, zf) F5f(theta, r, z, thetaf, rf, zf);
    % 执行积分计算
    F5 = integral2(F5_integrand, 0, a, 0, b);
end
