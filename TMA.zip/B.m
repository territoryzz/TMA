%B
function [B] = B(theta, r, z, omega, t, theta0, a, b, ka)
B = sqrt( Bz(theta, r, z, omega, t, theta0, a, b, ka).^2+Br(theta, r, z, omega, t, theta0, a, b, ka).^2+...
    Btheta(theta, r, z, omega, t, theta0, a, b, ka).^2 );
end