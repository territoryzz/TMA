%Btheta
function [Btheta] = Btheta(theta, r, z, omega, t, theta0, a, b, ka)
thetaf=Theta2(omega,t,theta0);
Btheta = ka*sin(omega*t).*sin(thetaf-theta).*F7(theta, r, z, thetaf, a, b);
end