clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);


% 打开文件以读取
fileID = fopen('max_value_theta_phi.txt', 'r');
% 读取文件中的数据
data = fscanf(fileID, '最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n');
% 关闭文件
fclose(fileID);

% 提取数据
max_value = data(1);
max_theta = data(2);
max_theta_deg = data(3);
max_phi = data(4);
max_phi_deg = data(5);

% 显示结果
fprintf('最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n', max_value, max_theta,max_theta_deg,max_phi, max_phi_deg);



%R的选取应与DataTreat_1D_Normalized_and_FindWide中保持一致
%取t=1/4T
beta = 5;
R = beta * a;
t_factor = 1/4 ;
t_fixed =t_factor * 2*pi/omega;

% 获取 S 数组的尺寸
load('S_values.mat');

[num_theta, num_phi] = size(S_values);
num_points_phi = num_phi;
num_points_theta = num_theta;

%% 绘制theta = theta_max下的分贝图
% 定义要绘制的 phi 范围（以度为单位）
phi_degrees = linspace(0, 180, num_phi); % 修改为您希望的 phi 范围（以度为单位）

% 创建存储 phi 和分贝值的数组
phi_values = zeros(size(phi_degrees));
dB_phi_values = zeros(size(phi_degrees));

% 循环计算每个 phi 对应的分贝值
for i = 1:length(phi_degrees)
    % 计算当前 phi 对应的分贝值
    phi_radians = deg2rad(phi_degrees(i)); % 将角度转换为弧度
    s_sphere_phi = S_sphere(max_theta, R, phi_radians, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu); % 使用最大值作为参考功率值
    s_ref_phi = s_sphere_phi/max_value;
    dB = 10 * log10(s_ref_phi); % 计算分贝值
    
    % 存储 phi 和分贝值
    phi_values(i) = phi_degrees(i);
    dB_phi_values(i) = dB;
end

% 绘制分贝图（使用平滑的线）
figure;
plot(phi_values, dB_phi_values);

% 添加 -3dB 的水平线
yline(-3, '--', '-3 dB');

% 添加标签和标题
xlabel('Phi (degrees)');
ylabel('S (dB)');
title(['S dB plot at max theta = ', num2str(max_theta_deg), '°']);




%% 绘制phi = phi_max下的分贝图
% 定义要绘制的 theta 范围（以度为单位）
theta_degrees = linspace(0, 360, num_theta); % 修改为您希望的 theta 范围（以度为单位）

% 创建存储 theta 和分贝值的数组
theta_values = zeros(size(theta_degrees));
dB_theta_values = zeros(size(theta_degrees));

% 循环计算每个 theta 对应的分贝值
for i = 1:length(theta_degrees)
    % 计算当前 theta 对应的分贝值
    theta_radians = deg2rad(theta_degrees(i)); % 将角度转换为弧度
    s_sphere_theta = S_sphere(theta_radians, R, max_phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu); % 使用最大值作为参考功率值
    s_ref_theta = s_sphere_theta/max_value;
    dB = 10 * log10(s_ref_theta); % 计算分贝值
    
    % 存储 phi 和分贝值
    theta_values(i) = theta_degrees(i);
    dB_theta_values(i) = dB;
end

% 绘制分贝图（使用平滑的线）
figure;
plot(theta_values, dB_theta_values);

% 添加 -3dB 的水平线
yline(-3, '--', '-3 dB');

% 添加标签和标题
xlabel('Theta (degrees)');
ylabel('S (dB)');
title(['S dB plot at max phi = ', num2str(max_phi_deg), '°']);





%% 保存数据并在origin中画图

% 构建文件名,储存phi变化的
file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_dB/With_Phi/data_R=%dL_theta0=%d_thetaf=%0.3f_t=%0.2fT.csv', beta, theta0,max_theta_deg, t_factor);

% 检查文件夹是否存在，如果不存在则创建
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_dB/With_Phi/';
if ~exist(folder_path, 'dir')
    mkdir(folder_path);
end  

% 构建要保存的数据矩阵
data = [phi_values', dB_phi_values'];
            
% 保存数据到 CSV 文件
writematrix(data, file_name);





% 构建文件名,储存theta变化的
file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_dB/With_Theta/data_R=%dL_theta0=%d_phif=%0.3f_t=%0.2fT.csv', beta, theta0,max_phi_deg, t_factor);

% 检查文件夹是否存在，如果不存在则创建
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/1D_S_dB/With_Theta/';
if ~exist(folder_path, 'dir')
    mkdir(folder_path);
end  

% 构建要保存的数据矩阵
data = [theta_values', dB_theta_values'];
            
% 保存数据到 CSV 文件
writematrix(data, file_name);





%% 找到最大值及其位置
[max_value, max_index] = max(S_values(:));
[max_row, max_col] = ind2sub(size(S_values), max_index);



%% 找到 -3dB 波束范围

% 清理数据，替换无效值
dB_theta_values_clean = dB_theta_values;
dB_theta_values_clean(isinf(dB_theta_values_clean) | isnan(dB_theta_values_clean)) = 0; % 将无效值替换为 0

half_max_power = -3;
half_power_theta_index = find(dB_theta_values >= half_max_power);
half_power_phi_index = find(dB_phi_values>= half_max_power);


% theta方向半功率波束宽度的计算
% 检查是否出现旁瓣
% 检查 half_power_theta_index 的连续性
is_continuous = all(diff(half_power_theta_index) == 1);

if is_continuous
    % 连续情况下计算半功率波束宽度
    hpbw_theta = max(theta_degrees(half_power_theta_index)) - min(theta_degrees(half_power_theta_index));
    theta_theta_min =  min(theta_degrees(half_power_theta_index));
    theta_theta_max = max(theta_degrees(half_power_theta_index));
else

    % 非连续情况下找到突变位置
    threshold = 2;  % 设定一个阈值，表示两个相邻元素的最小差异
    mutate_points_theta = zeros(2, 1);
    max_theta_index = find(half_power_theta_index == max_row);

    % 从最大索引向前找突变位置
    for i = max_theta_index:-1:2
        if abs(half_power_theta_index(i) - half_power_theta_index(i-1)) >= threshold 
            mutate_points_theta(1) = half_power_theta_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_theta(1) = half_power_theta_index(i);
    end

    % 从最大索引向后找突变位置
    for i = max_theta_index:numel(half_power_theta_index)-1
        if abs(half_power_theta_index(i+1) - half_power_theta_index(i)) >= threshold
            mutate_points_theta(2) = half_power_theta_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
         mutate_points_theta(2) = half_power_theta_index(i);
    end

    % 计算突变位置对应的 theta 范围和半功率波束宽度
    theta_theta_min = theta_degrees(mutate_points_theta(1));
    theta_theta_max = theta_degrees(mutate_points_theta(2));
    hpbw_theta = theta_theta_max - theta_theta_min;
end

% 显示结果
fprintf('波束范围为：theta 方向 %f 度 到 %f 度\n', theta_theta_min, theta_theta_max);
fprintf('半功率波束宽度为：theta 方向 %f 度\n', hpbw_theta);



% phi方向半功率波束宽度的计算
% 检查是否出现旁瓣
% 检查 half_power_phi_index 的连续性
is_continuous = all(diff(half_power_phi_index) == 1);

if is_continuous
    % 连续情况下计算半功率波束宽度
    hpbw_phi = max(phi_degrees(half_power_phi_index)) - min(phi_degrees(half_power_phi_index));
    phi_phi_min =  min(phi_degrees(half_power_phi_index));
    phi_phi_max = max(phi_degrees(half_power_phi_index));
else

    % 非连续情况下找到突变位置
    mutate_points_phi = zeros(2, 1);
    max_phi_index = find(half_power_phi_index == max_col);

    % 从最大索引向前找突变位置
    for i = max_phi_index:-1:2
        if abs(half_power_phi_index(i) - half_power_phi_index(i-1)) >= threshold 
            mutate_points_phi(1) = half_power_phi_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
         mutate_points_phi(1) = half_power_phi_index(i);
    end

    % 从最大索引向后找突变位置
    for i = max_phi_index:numel(half_power_phi_index)-1
        if abs(half_power_phi_index(i+1) - half_power_phi_index(i)) >= threshold
            mutate_points_phi(2) = half_power_phi_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_phi(2) = half_power_phi_index(i);
    end

    % 计算突变位置对应的 theta 范围和半功率波束宽度
    phi_phi_min = phi_degrees(mutate_points_phi(1));
    phi_phi_max = phi_degrees(mutate_points_phi(2));
    hpbw_phi = phi_phi_max - phi_phi_min;
end

% 显示结果
fprintf('波束范围为：phi 方向 %f 度 到 %f 度\n', phi_phi_min, phi_phi_max);
fprintf('半功率波束宽度为：phi 方向 %f 度\n', hpbw_phi);