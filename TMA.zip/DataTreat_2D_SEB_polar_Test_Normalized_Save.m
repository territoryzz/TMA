clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;

% 设置 omega、theta0、beta 和 t_factor 的取值范围
omega_values = [30, 300, 3000, 30000];
theta0_values = [3, 30, 60, 90];
beta_values = [2, 5, 10, 20];
t_factor_values = [1/12, 1/6, 1/4, 1/3, 5/12, 1/2];
z_point_values = [-0.5, 0.05, 0.5];  % z_point 取值列表


%% 循环计算和保存数据
for omega = omega_values
    for theta0 = theta0_values
        % 设置A，phi的计算常数
        ka = -mu * sigma * theta0 * omega / (4*pi);
        kphi2 = sigma / (4*pi*epsilon0);
        kphi1 = -sigma / (4*pi*epsilon0);

        for beta = beta_values
           r_fixed= beta * a;

            for t_factor = t_factor_values
                t_fixed = t_factor * 2*pi/omega;
                for z_fixed = z_point_values


% 定义 theta 范围
theta = linspace(0, 2*pi, 100);

% 计算对应位置的场强大小 B
B_values = zeros(size(theta));
for i = 1:numel(theta)
    B_values(i) = B(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka);
end

% 归一化场强大小到 [0, 1] 的范围
B_values_normalized = B_values / max(B_values);


% 计算对应位置的场强大小 E
E_values = zeros(size(theta));
for i = 1:numel(theta)
    E_values(i) = E(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
end

% 归一化场强大小到 [0, 1] 的范围
E_values_normalized = E_values / max(E_values);


% 计算对应位置的场强大小 S
S_values = zeros(size(theta));
for i = 1:numel(theta)
    S_values(i) = S(theta(i), r_fixed, z_fixed, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
end

% 归一化场强大小到 [0, 1] 的范围
S_values_normalized = S_values / max(S_values);



%% 保存数据并在origin中画图

% 构建文件名
file_name = sprintf('D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/2D_Field_polar/Test_Normalized/data_r=%.2f_theta0=%d_Omega=%d_t=%.3fT_z=%.2f.csv', r_fixed, theta0,omega,t_factor, z_fixed);

% 检查文件夹是否存在，如果不存在则创建
folder_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/2D_Field_polar/Test_Normalized/';
if ~exist(folder_path, 'dir')
    mkdir(folder_path);
end  

% 构建要保存的数据矩阵
data = [theta', B_values_normalized', E_values_normalized', S_values_normalized'];
             
% 保存数据到 CSV 文件
writematrix(data, file_name);
               

                end
            end
        end
    end
end

disp('数据保存完成！');
