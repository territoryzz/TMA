clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);

%考虑绘制波瓣图，那么必须考虑在远场情况下，波长条件难以满足，故仅满足器件尺寸条件和瑞丽条件r>2*D^2/lambda
%取t=1/4T
beta = 20;
R = beta * a;
t_factor = 1/4 ;
t_fixed =t_factor * 2*pi/omega;

% 定义网格点数量
num_theta = 361; % 对应于角度范围 eps 到 2*pi，步长为 2*pi/180
num_phi = 181; % 对应于角度范围 eps 到 pi，步长为 pi/180

% 初始化笛卡尔坐标
x = zeros(num_phi, num_theta);
y = zeros(num_phi, num_theta);
z = zeros(num_phi, num_theta);

% 计算磁场值
B = zeros(num_phi, num_theta);
E = zeros(num_phi, num_theta);
S = zeros(num_phi, num_theta);
for i = 1:num_theta
    for j = 1:num_phi
        % 计算球坐标下的角度
        theta = (i - 1) * 2 * pi / 180; % 角度从 0 到 2pi
        phi = (j - 1) * pi / 180; % 角度从 0 到 pi
        
        % 计算磁场值
        S(j, i) = S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
        
        % 将球坐标转换为笛卡尔坐标
        %[x, y, z] = sph2cart(theta, phi, r) 
        % r为极径
        % theta 是极角，以弧度表示，范围通常是[0,2π]
        % phi 为方位角，以弧度表示，范围通常是[0,π)
        %需要特别注意，我定义的theta与phi和标准定义下的theta和phi是刚好相反的
        [x(j, i), y(j, i), z(j, i)] = sph2cart(theta ,phi , R);
    end
end



% 绘制立体方向图，并添加颜色表示大小
figure;
surf(x, y, z, S);
title('S的立体方向图');
xlabel('x'), ylabel('y'), zlabel('S(\theta,\phi)');
colorbar; % 添加颜色条