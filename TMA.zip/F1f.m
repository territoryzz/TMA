%F1f
function [F1f] = F1f(theta, r, z, thetaf, rf, zf)
    F1f = 1./(r.^2 + rf.^2 -2.*r.*rf.*cos(theta-thetaf)+(z-zf).^2).^3/2;
end
