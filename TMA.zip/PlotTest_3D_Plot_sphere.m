clear;
close all;
clc;

%% 定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6;
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1;
theta0 = 30;

%% 设置 A, phi 的计算常数
ka = -mu * sigma * theta0 * omega / (4 * pi);
kphi2 = sigma / (4 * pi * epsilon0);
kphi1 = -sigma / (4 * pi * epsilon0);

% 计算远场条件下的波瓣图
beta = 5;
R = beta * a;
t_factor = 1/4;
t_fixed = t_factor * 2 * pi / omega;

% 定义网格点数量
num_theta = 361; % 角度范围 eps 到 2*pi
num_phi = 181;   % 角度范围 eps 到 pi

% 初始化笛卡尔坐标
x = zeros(num_phi, num_theta);
y = zeros(num_phi, num_theta);
z = zeros(num_phi, num_theta);

% 初始化磁场值
B = zeros(num_phi, num_theta);
E = zeros(num_phi, num_theta);
S = zeros(num_phi, num_theta);
for i = 1:num_theta
    for j = 1:num_phi
        theta = (i - 1) * 2 * pi / (num_theta - 1); % 角度从 0 到 2pi
        phi = (j - 1) * pi / (num_phi - 1); % 角度从 0 到 pi
        
        % 计算磁场值
        B(j, i) = B_sphere(R, theta, phi, t_fixed, omega, theta0, a, b, ka);
        E(j, i) = E_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2);
        S(j, i) = S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu);
        
        % 将球坐标转换为笛卡尔坐标
        [x(j, i), y(j, i), z(j, i)] = sph2cart(theta, pi/2 - phi, R);
    end
end

% 归一化处理
B_normalized = B / max(B(:)); 
E_normalized = E / max(E(:)); 
S_normalized = S / max(S(:)); 

% 设置保存路径
save_path = 'D:/Users/研究/设定中间函数求解极坐标下两极板辐射/packageIntegralPlotPackage/result/TestPlot/';

% 绘制 B 的归一化立体方向图
figure;
% set(gcf, 'Color', 'none'); % 设置图形背景透明
axes_handle = gca;
set(axes_handle, 'Color', 'none'); % 设置坐标区背景透明
surf(x, y, z, B_normalized, 'EdgeColor', 'none'); % 去除边框线
% surf(x, y, z, B_normalized, 'EdgeColor', 'none'); % 去除边框线
colormap(jet); % 更鲜艳的颜色映射
alpha(0.7); % 设置透明度
title('B的归一化立体方向图');
xlabel('x'), ylabel('y'), zlabel('B_normalized(\theta,\phi)');
colorbar;
% set(gca, 'Color', 'none'); % 设置背景透明
saveas(gcf, fullfile(save_path, 'B_sphere_plot.svg'));
% exportgraphics(gcf, fullfile(save_path, 'B_sphere_plot.svg'), 'BackgroundColor', 'none');


% 绘制 E 的归一化立体方向图
figure;
axes_handle = gca;
set(axes_handle, 'Color', 'none'); % 设置坐标区背景透明
surf(x, y, z, E_normalized, 'EdgeColor', 'none'); % 去除边框线
% surf(x, y, z, E_normalized, 'EdgeColor', 'none');
colormap(hot); % 更鲜艳的颜色映射
alpha(0.7); % 设置透明度
title('E的归一化立体方向图');
xlabel('x'), ylabel('y'), zlabel('E_normalized(\theta,\phi)');
colorbar;
% set(gca, 'Color', 'none'); % 设置背景透明
saveas(gcf, fullfile(save_path, 'E_sphere_plot.svg'));
% exportgraphics(gcf, fullfile(save_path, 'E_sphere_plot.svg'), 'BackgroundColor', 'none');

% 绘制 S 的归一化立体方向图
figure;
axes_handle = gca;
set(axes_handle, 'Color', 'none'); % 设置坐标区背景透明
surf(x, y, z, S_normalized, 'EdgeColor', 'none'); % 去除边框线
% surf(x, y, z, S_normalized, 'EdgeColor', 'none');
colormap(jet); % 更鲜艳的颜色映射
alpha(0.7); % 设置透明度
title('S的归一化立体方向图');
xlabel('x'), ylabel('y'), zlabel('S_normalized(\theta,\phi)');
colorbar;
set(gca, 'Color', 'none'); % 设置背景透明
saveas(gcf, fullfile(save_path, 'S_sphere_plot.svg'));
% exportgraphics(gcf, fullfile(save_path, 'S_sphere_plot.svg'), 'BackgroundColor', 'none');

