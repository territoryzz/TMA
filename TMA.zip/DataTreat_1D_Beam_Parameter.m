clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 30;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);

%考虑绘制波瓣图，那么必须考虑在远场情况下，波长条件难以满足，故仅满足器件尺寸条件和瑞丽条件r>2*D^2/lambda
%R的选取应与DataTreat_1D_Normalized_and_FindWide中保持一致
%取t=1/4T
beta = 5;
R = beta * a;
t_fixed =1/4 * 2*pi/omega;

%% 波束范围
   % 从文件中提取最大值数据
   % 打开文件以读取
   fileID = fopen('max_value_theta_phi.txt', 'r');
   % 读取文件中的数据
   data = fscanf(fileID, '最大值为 %f，在 theta = %f = %f°, phi = %f = %f° 处达到。\n');
   % 关闭文件
   fclose(fileID);
   max_value = data(1);

S_averageIntegral = 0; % 初始化积分结果

% 定义角度范围和步长


% 获取 S 数组的尺寸
load('S_values.mat');

[num_theta, num_phi] = size(S_values);
num_points_phi = num_phi;
num_points_theta = num_theta;


d_phi = pi / (num_points_phi - 1);
d_theta = 2 * pi / (num_points_theta - 1);

% 对 phis 和 thetas 进行循环求和
    for i = 2:num_points_phi
        phi = (i - 1) * d_phi;
        for j = 2:num_points_theta
            theta = (j - 1) * d_theta;
            % 计算 S_sphere
            S_sphere_val = S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu)/ max_value  ;
            % 累加到积分结果中
            S_averageIntegral = S_averageIntegral + S_sphere_val * sin(phi) * d_phi * d_theta;
        end
    end

% 乘以步长得到积分值
OmegaA =  S_averageIntegral; 

% 显示结果
fprintf('波束范围为: %f\n', S_averageIntegral);

% 打开文件以写入结果
fileID = fopen('BeamParameter_OmegaA.txt', 'w');
% 将结果写入文件
fprintf(fileID, '波束范围为: %f\n', S_averageIntegral);

% 关闭文件
fclose(fileID);



%% 定向性D
D = 4*pi/OmegaA;

% 显示结果
fprintf('定向性为: %f\n', D );

% 打开文件以写入结果
fileID = fopen('BeamParameter_Directionality.txt', 'w');
% 将结果写入文件
fprintf(fileID, '定向性为: %f\n', D);

% 关闭文件
fclose(fileID);

%% 有效口径
A_m = D * (2*pi*c/omega)^2 / (4*pi);

% 显示结果
fprintf('有效口径为: %f\n', A_m );

% 打开文件以写入结果
fileID = fopen('BeamParameter_EffectiveAperture.txt', 'w');
% 将结果写入文件
fprintf(fileID, '有效口径为: %f\n', A_m);

% 关闭文件
fclose(fileID);




%% 波束效率
% 生成一组离散的 theta 和 phi 值
theta_range = linspace(0, 2*pi, num_points_theta);
phi_range = linspace(0, pi, num_points_phi);
zero_power = 1e-2 *max_value;


%% 找到最大值及其位置
[max_value, max_index] = max(S_values(:));
[max_row, max_col] = ind2sub(size(S_values), max_index);

% 在 theta 方向找到零功率点
zero_power_theta_index = find(S_values(:, max_col) >= zero_power);
if isempty(zero_power_theta_index)
    error('未找到 theta 方向上的零功率点。');
end

% 在 phi 方向找到零功率点
zero_power_phi_index = find(S_values(max_row, :) >= zero_power);
if isempty(zero_power_phi_index)
    error('未找到 phi 方向上的零功率点。');
end


% theta方向零功率波束宽度的计算
% 检查是否出现旁瓣
% 检查 zero_power_theta_index 的连续性
is_continuous = all(diff(zero_power_theta_index) == 1);

if is_continuous
    % 连续情况下计算波束宽度
    zpbw_theta = max(theta_range(zero_power_theta_index)) - min(theta_range(zero_power_theta_index));
    theta_zero_min =  min(theta_range(zero_power_theta_index));
    theta_zero_max = max(theta_range(zero_power_theta_index));
else

    % 非连续情况下找到突变位置
    threshold = 2;  % 设定一个阈值，表示两个相邻元素的最小差异
    mutate_points_theta = zeros(2, 1);
    max_theta_index = find(zero_power_theta_index == max_row);

    % 从最大索引向前找突变位置
    for i = max_theta_index:-1:2
        if abs(zero_power_theta_index(i) - zero_power_theta_index(i-1)) >= threshold 
            mutate_points_theta(1) = zero_power_theta_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_theta(1) = zero_power_theta_index(i);
    end

    % 从最大索引向后找突变位置
    for i = max_theta_index:numel(zero_power_theta_index)-1
        if abs(zero_power_theta_index(i+1) - zero_power_theta_index(i)) >= threshold
            mutate_points_theta(2) = zero_power_theta_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_theta(2) = zero_power_theta_index(i);
    end

    % 计算突变位置对应的 theta 范围和半功率波束宽度
    theta_zero_min = theta_range(mutate_points_theta(1));
    theta_zero_max = theta_range(mutate_points_theta(2));
    zpbw_theta = theta_zero_max - theta_zero_min;
end

% 显示结果
fprintf('零功率波束范围为：theta 方向 %f 度 到 %f 度\n', rad2deg(theta_zero_min), rad2deg(theta_zero_max));
fprintf('零功率波束宽度为：theta 方向 %f 度\n', rad2deg(zpbw_theta));



% phi方向半功率波束宽度的计算
% 检查是否出现旁瓣
% 检查 zero_power_phi_index 的连续性
is_continuous = all(diff(zero_power_phi_index) == 1);

if is_continuous
    % 连续情况下计算半功率波束宽度
    zpbw_phi = max(phi_range(zero_power_phi_index)) - min(phi_range(zero_power_phi_index));
    phi_zero_min =  min(phi_range(zero_power_phi_index));
    phi_zero_max = max(phi_range(zero_power_phi_index));
else

    % 非连续情况下找到突变位置
    mutate_points_phi = zeros(2, 1);
    max_phi_index = find(zero_power_phi_index == max_col);

    % 从最大索引向前找突变位置
    for i = max_phi_index:-1:2
        if abs(zero_power_phi_index(i) - zero_power_phi_index(i-1)) >= threshold 
            mutate_points_phi(1) = zero_power_phi_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_phi(1) = zero_power_phi_index(i);
    end

    % 从最大索引向后找突变位置
    for i = max_phi_index:numel(zero_power_phi_index)-1
        if abs(zero_power_phi_index(i+1) - zero_power_phi_index(i)) >= threshold
            mutate_points_phi(2) = zero_power_phi_index(i);
            break;  % 找到第一个突变位置就退出循环
        end
        mutate_points_phi(2) = zero_power_phi_index(i);
    end

    % 计算突变位置对应的 theta 范围和半功率波束宽度
    phi_zero_min = phi_range(mutate_points_phi(1));
    phi_zero_max = phi_range(mutate_points_phi(2));
    zpbw_phi = phi_zero_max - phi_zero_min;
end

% 显示结果
fprintf('零功率波束范围为：phi 方向 %f 度 到 %f 度\n', rad2deg(phi_zero_min), rad2deg(phi_zero_max));
fprintf('零功率波束宽度为：phi 方向 %f 度\n', rad2deg(zpbw_phi));





% 初始化积分结果
S_averageIntegral_Main = 0;

% 定义积分的角度范围和步长
theta_end = theta_zero_max;
theta_start = theta_zero_min;
phi_end = phi_zero_max;
phi_start = phi_zero_min;

% 定义角度范围和步长
num_points_phi = num_phi;
num_points_theta = num_theta;
d_phi = (phi_end - phi_start) / (num_points_phi - 1);
d_theta = (theta_end - theta_start) / (num_points_theta - 1);

% 对 phis 和 thetas 进行循环求和
for i = 2:num_points_phi
    phi = phi_start + (i - 1) * d_phi;
    for j = 2:num_points_theta
        theta = theta_start + (j - 1) * d_theta;
        
        % 计算 S_sphere
        S_sphere_val = S_sphere(theta, R, phi, omega, t_fixed, theta0, a, b, ka, kphi1, kphi2, mu) / max_value;
        
        % 累加到积分结果中
        S_averageIntegral_Main = S_averageIntegral_Main + S_sphere_val * sin(phi) * d_phi * d_theta;
    end
end

OmegaM = S_averageIntegral_Main;

% 显示结果
fprintf('主瓣波束范围为: %f\n', S_averageIntegral_Main);

% 将结果写入文件
fileID = fopen('BeamParameter_OmegaM.txt', 'w');
fprintf(fileID, '主瓣波束范围为: %f\n', S_averageIntegral_Main);
fclose(fileID);


epsilon_M = OmegaM / OmegaA;

% 显示结果
fprintf('波束效率为: %f\n', epsilon_M);

% 将结果写入文件
fileID = fopen('BeamParameter_Efficiency.txt', 'w');
fprintf(fileID, '波束效率为: %f\n', epsilon_M);
fclose(fileID);
