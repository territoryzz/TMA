clear ;
close all;
clc;

%%定义物理量参数
c = 299792458;
p = 1;
epsilon0 = 8.854187817e-12;
sigma = 10e-6; 
omega = 30;
mu = 4*pi*10^-7;
a = 0.1;
b = 0.1; 
theta0 = 3;

%%设置A，phi的计算常数
ka=-mu*sigma*theta0*omega/(4*pi);
kphi2=sigma/(4*pi*epsilon0);
kphi1=-sigma/(4*pi*epsilon0);


%% 选取固定点随时间变换的图像
r_point = 0.5;
thetafAng= -theta0;
theta_point = deg2rad(thetafAng); % 将角度转换为弧度
z_point = -0.5;

% 时间向量
t = linspace(0, 3*2*pi/omega, 200); % 假设三个周期的波

% 绘制极板运动作为参考
figure; % 创建新的图形窗口
Theta2_values=rad2deg(Theta2(omega,t,theta0));
plot(t, Theta2_values);
xlabel('时间');
ylabel('Theta2');
title('Theta2随时间变化');

thetaf = Theta2(omega,t,theta0); % theta2函数内完成了将角度值转换为弧度制的过程

% 绘制B、E、S大小随时间变化的图
B_values = zeros(size(t));
E_values = zeros(size(t));
S_values = zeros(size(t));

for i = 1:length(t)
    B_values(i) = B(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka);
    E_values(i) = E(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2);
    S_values(i) = S(theta_point, r_point,z_point, omega, t(i), theta0, a, b, ka, kphi1, kphi2, mu);
end

% 创建图形并添加标题
figure;
plot(t, B_values);
xlabel('时间');
ylabel('B');
title(['固定点（r = ', num2str(r_point), ', theta_f = ', num2str(thetafAng), '°, z = ', num2str(z_point), '）随时间变化的 B 的大小']);
grid on;

figure;
plot(t, E_values);
xlabel('时间');
ylabel('E');
title(['固定点（r = ', num2str(r_point), ', theta_f = ', num2str(thetafAng), '°, z = ', num2str(z_point), '）随时间变化的 E 的大小']);
grid on;

figure;
plot(t, S_values);
xlabel('时间');
ylabel('S');
title(['固定点（r = ', num2str(r_point), ', theta_f = ', num2str(thetafAng), '°, z = ', num2str(z_point), '）随时间变化的 S 的大小']);
grid on;

